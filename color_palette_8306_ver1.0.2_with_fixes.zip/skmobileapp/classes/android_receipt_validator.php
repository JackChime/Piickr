<?php

class SKMOBILEAPP_CLASS_AndroidReceiptValidator
{
	protected $key = '';

    function __construct( $key )
    {
        $this->key = $key;
    }

	public function validateReceipt($signature, $receipt)
	{
        try{
            $public_key_base64 = $this->key;
        } catch (Exception $e){
            return false;
        }
        $key = "-----BEGIN PUBLIC KEY-----\n" .
                chunk_split($public_key_base64, 64, "\n") .
                '-----END PUBLIC KEY-----';
        $key = openssl_get_publickey($key);
        $signature = base64_decode($signature);
        $result = @openssl_verify($receipt, $signature, $key, OPENSSL_ALGO_SHA1);
        if ( 1 === $result )
        {
            return true;
        }
        else
        {
            return false;
        }
	}
}