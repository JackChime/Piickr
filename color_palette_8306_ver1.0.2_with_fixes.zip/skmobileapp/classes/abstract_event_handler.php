<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */
abstract class SKMOBILEAPP_CLASS_AbstractEventHandler
{
    /**
     * Generic init
     */
    public function genericInit()
    {
        $eventManager = OW::getEventManager();

        $eventManager->bind('mailbox.send_message', array($this, 'afterMailboxMessageSent'));
        $eventManager->bind(OW_EventManager::ON_APPLICATION_INIT, array($this, 'checkApiUrl'));
        $eventManager->bind(OW_EventManager::ON_USER_UNREGISTER, array($this, 'onUserUnRegister'));
    }

    /**
     * On user un register
     *
     * @param OW_Event $e
     */
    public function onUserUnRegister( OW_Event $e )
    {
        $params = $e->getParams();

        SKMOBILEAPP_BOL_Service::getInstance()->deleteUserData($params['userId']);
    }

    /**
     * After mailbox message sent
     *
     * @param OW_Event $event
     * @return void
     */
    public function afterMailboxMessageSent( OW_Event $event )
    {
        $params = $event->getParams();

        if ( !empty($params["isSystem"]) )
        {
            return;
        }

        /**
         * @var SKMOBILEAPP_BOL_PushService $pushService
         */
        $pushService = SKMOBILEAPP_BOL_PushService::getInstance();

        $userId = $params["recipientId"];
        $senderId = $params["senderId"];
        $conversationId = $params["conversationId"];

        $senderName = BOL_UserService::getInstance()->getDisplayName($senderId);
        $text = strip_tags($params["message"]);
        $dataText = json_decode($text, true);

        if (!is_array($dataText))
        {
            $pushService->sendNotification($userId,
                array(
                    "key" => "pn_new_message",
                    "titleKey" => "pn_new_message_title",
                    "vars" => array(
                        "username" => $senderName,
                        "message" => $text
                    )
                ),
                array(
                    "type" => SKMOBILEAPP_BOL_PushService::TYPE_MESSAGE,
                    "conversationId" => (int) $conversationId,
                    "senderId" => (int) $senderId
                )
            );
        }
    }

    /**
     * Check api url
     *
     * @return void
     */
    public function checkApiUrl()
    {
        try
        {
            $apiRoute = OW::getRouter()->getRoute('skmobileapp.api');

            if ( stristr($_SERVER['REQUEST_URI'], $apiRoute->getRoutePath()) )
            {
                OW::getRouter()->setUri($apiRoute->getRoutePath()); // redirect all actions to the index action
            }
        }
        catch(Exception $e)
        {}
    }
}
