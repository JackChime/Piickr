<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */

// Firebase
use sngrl\PhpFirebaseCloudMessaging\Client;
use sngrl\PhpFirebaseCloudMessaging\Message;
use sngrl\PhpFirebaseCloudMessaging\Recipient\Device;
use sngrl\PhpFirebaseCloudMessaging\Notification;

// Apns
use Apple\ApnPush\Certificate\Certificate;
use Apple\ApnPush\Notification as ApnsNotification;
use Apple\ApnPush\Notification\Connection as NotificationConnection;
use Apple\ApnPush\Notification\Message as ApnsMessage;


class SKMOBILEAPP_BOL_PushService
{
    use OW_Singleton;

    const TYPE_MESSAGE = "message";
    const TYPE_MATCHED_USER = "matchedUser";

    const MESSAGE_LENGTH = 200;

    const CERT_FILE_NAME = "apns_cert.pem";

    /**
     * @var SKMOBILEAPP_BOL_DeviceService
     */
    private $deviceService;

    private function __construct()
    {
        $this->deviceService = SKMOBILEAPP_BOL_DeviceService::getInstance();
    }

    public function getCertificateFilePath()
    {
        $dir = OW::getPluginManager()->getPlugin("skmobileapp")->getPluginFilesDir();

        return $dir . self::CERT_FILE_NAME;
    }

    /**
     * @param $userId
     * @param array $langData
     * @param array $params
     * @param string $soundName (with extension)
     * @return void
     */
    public function sendNotification($userId, array $langData, array $params, $soundName = null )
    {
        if (!OW::getConfig()->getValue("skmobileapp", "pn_enabled")){
            return;
        }

        $defaultLangPrefix = "skmobileapp";

        if ( isset($langData["langPrefix"]) && strlen($langData["langPrefix"]) > 0 ) {
            $defaultLangPrefix = $langData["langPrefix"];
        }

        if ( empty($langData["key"]) || empty($params["type"]) || empty($langData["titleKey"]) )
        {
            return;
        }

        $devices = $this->deviceService->findByUserId($userId);

        if ( empty($devices) )
        {
            return;
        }

        $languageService = BOL_LanguageService::getInstance();

        /* @var $device SKMOBILEAPP_BOL_Device */
        foreach ( $devices as $device )
        {
            $deviceProps = $device->getProperties();
            $langDto = $languageService->getCurrent();

            if ( !empty($deviceProps['lang']) )
            {
                $customLang = $languageService->findByTag($deviceProps['lang']);

                if ( $customLang )
                {
                    $langDto = $customLang;
                }
            }

            if ( empty($langData["vars"]) )
            {
                $langData["vars"] = array();
            }

            $params["message"] = $languageService->getText($langDto->getId(), $defaultLangPrefix, $langData["key"],
                $langData["vars"]);
            $params["title"] = $languageService->getText($langDto->getId(), $defaultLangPrefix, $langData["titleKey"],
                $langData["vars"]);

            // iOS background data
            $params['data']['content-available'] = 1;
            // Android background data
            $params['content-available'] = 1;
            // Message uniq id
            $params['uuid'] = uniqid();


            if( $device->platform == 'Android')
            {
                $this->sendToFirebase($device->token, $params, $soundName);
            }
            else
            {
                $this->sendToApns($device->token, $params, $soundName);
            }
        }
    }

    private function sendToFirebase($token, $params, $soundName = null)
    {
        $server_key = OW::getConfig()->getValue("skmobileapp", "pn_server_key");

        if (empty($server_key)){
            return;
        }

        $client = new Client();

        $client->setApiKey($server_key);
        $client->injectGuzzleHttpClient(new \GuzzleHttp\Client());

        $notification = new Notification($params["title"], $params["message"]);
        $notification->setData($params);

        if  ($soundName) {
            $notification->setSound($soundName);
        }

        $message = new Message();
        $message->setPriority("high");

        $message->addRecipient(new Device($token));
        $message->setData($params);
        $message->setNotification($notification);

        $client->send($message);
    }

    private function sendToApns($token, $params, $soundName = null)
    {
        if (!file_exists($this->getCertificateFilePath())){
            return;
        }

        $message = new ApnsMessage($token, $params['message']);
        $message->setCustomData($params);

        if ($soundName) {
            $message->setSound($soundName);
        }

        $certificate = new Certificate(
            $this->getCertificateFilePath(),
            OW::getConfig()->getValue("skmobileapp", 'pn_apns_pass_phrase')
        );

        $isSandbox = OW::getConfig()->getValue("skmobileapp", "pn_apns_mode") == "test";

        $connection = new NotificationConnection($certificate, $isSandbox);
        $notificationService = new ApnsNotification($connection);

        $notificationService->send($message);
    }

}
