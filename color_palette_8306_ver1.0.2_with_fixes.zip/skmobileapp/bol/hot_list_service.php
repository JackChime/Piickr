<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */

class SKMOBILEAPP_BOL_HotListService extends SKMOBILEAPP_BOL_Service
{
    use OW_Singleton;

    /**
     * Find by id
     *
     * @param integer $id
     * @param integer $userId
     * @return HOTLIST_BOL_User
     */
    public function findById($id, $userId = null)
    {
        $hotListDao = HOTLIST_BOL_UserDao::getInstance();
        $hotListDto = $hotListDao->findById($id);

        if ( $userId && $hotListDto && $hotListDto->userId != $userId )
        {
            return;
        }

        return $hotListDao;
    }

    /**
     * Find users
     *
     * @return array
     */
    public function findUsers()
    {
        return $this->formatHotListData(HOTLIST_BOL_Service::getInstance()->getHotList());
    }

    /**
     * Format hot list data
     *
     * @param array $hotListUsers
     * @return array
     */
    public function formatHotListData(array $hotListUsers)
    {
        $processedUsers = [];
        $ids = [];

        // process users
        foreach($hotListUsers as $key => $hotList) {
            // Skip deleted users
            $userDto = BOL_UserService::getInstance()->findUserById($hotList->userId);
            if (empty($userDto)) continue;

            $ids[] = $hotList->userId;

            $processedUsers[$hotList->userId] = [
                'id' => (int) $hotList->id,
                'userId' => (int) $hotList->userId,
                'timestamp' => (int) $hotList->timestamp,
                'avatar' => [],
                'displayName' => [],
                'userName' => []
            ];
        }

        // load avatars
        $avatarList = BOL_AvatarService::getInstance()->findByUserIdList($ids);

        foreach($avatarList as $avatar) {
            $processedUsers[$avatar->userId]['avatar'] = $this->getAvatarData($avatar, false);
        }

        // load display names
        $displayNames = BOL_UserService::getInstance()->getDisplayNamesForList($ids);

        foreach($displayNames as $userId => $displayName) {
            $processedUsers[$userId]['displayName'] = $displayName;
        }

        // load user names
        $userNames = BOL_UserService::getInstance()->getUserNamesForList($ids);

        foreach($userNames as $userId => $userName) {
            $processedUsers[$userId]['userName'] = $userName;
        }

        $data = [];
        foreach($processedUsers as $userData) {
            $data[] = $userData;
        }

        return $data;
    }

    /**
     * Find user
     *
     * @param $userId
     * @return mixed
     */
    public function findUser($userId)
    {
        $hotListDao = HOTLIST_BOL_UserDao::getInstance();

        $example = new OW_Example();
        $example->andFieldEqual('userId', $userId);

        return $hotListDao->findObjectByExample($example);
    }
}
