<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */

class SKMOBILEAPP_BOL_GuestsService extends SKMOBILEAPP_BOL_Service
{
    use OW_Singleton;

    /**
     * Find guest by id
     *
     * @param integer $id
     * @param integer $userId
     * @return array
     */
    function findGuestById($id, $userId = null)
    {
        $guestDao = OCSGUESTS_BOL_GuestDao::getInstance();
        $guestDto = $guestDao->findById($id);

        if ( $userId && $guestDto && $guestDto->userId != $userId )
        {
            return;
        }

        return $guestDto;
    }

    /**
     * Delete guest by id
     *
     * @param $id
     * @return void
     */
    function deleteGuestById($id)
    {
        $guestDao = OCSGUESTS_BOL_GuestDao::getInstance();
        $guestDao->deleteById($id);
    }

    /**
     * Find guests
     *
     * @param integer $userId
     * @param integer $page
     * @param integer $limit
     * @return array
     */
    function findGuests($userId, $page = 1, $limit = 1000)
    {
        $guests = OCSGUESTS_BOL_Service::getInstance()->findGuestsForUser($userId, $page, $limit);

        return $this->formatGuestData($userId, $guests);
    }

    /**
     * Format guest data
     *
     * @param integer $userId
     * @param array $guests
     * @return array
     */
    public function formatGuestData($userId, array $guests)
    {
        $processedGuests = [];
        $ids = [];

        // process guests
        foreach($guests as $guest) {
            $ids[] = $guest->guestId;
            $processedGuests[$guest->guestId] = [
                'id' => (int) $guest->id,
                'viewed' => (bool) $guest->viewed,
                'guestId' => (int) $guest->guestId,
                'visitTimestamp' => (int) $guest->visitTimestamp,
                'avatar' => [],
                'displayName' => [],
                'userName' => [],
                'matchActions' => []
            ];
        }

        // load matches
        $mathList = SKMOBILEAPP_BOL_UserMatchActionDao::getInstance()->findUserMatchActionsByUserIdList($userId, $ids);

        foreach($mathList as $matchAction) {
            $processedGuests[$matchAction->recipientId]['matchActions'] = [
                'type' => $matchAction->type,
                'userId' => (int) $matchAction->recipientId,
                'isMutual' => boolval($matchAction->mutual)
            ];
        }

        // load avatars
        $avatarList = BOL_AvatarService::getInstance()->findByUserIdList($ids);

        foreach($avatarList as $avatar) {
            $processedGuests[$avatar->userId]['avatar'] = $this->getAvatarData($avatar, false);
        }

        // load display names
        $displayNames = BOL_UserService::getInstance()->getDisplayNamesForList($ids);

        foreach($displayNames as $userId => $displayName) {
            $processedGuests[$userId]['displayName'] = $displayName;
        }

        // load user names
        $userNames = BOL_UserService::getInstance()->getUserNamesForList($ids);

        foreach($userNames as $userId => $userName) {
            $processedGuests[$userId]['userName'] = $userName;
        }

        $data = [];
        foreach($processedGuests as $bookmarkData) {
            $data[] = $bookmarkData;
        }

        return $data;
    }
}
