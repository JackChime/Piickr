<?php

/**
 * Data Transfer Object for `skmobileapp_devices` table.
 *
 * @author Sergei Kiselev <arrserg@gmail.com>
 * @package ow.plugin.skmobileapp.bol
 * @since 1.7.5
 */
class SKMOBILEAPP_BOL_Device extends OW_Entity
{
    /**
     * @var integer
     */
    public $id;

    /**
     * @var integer
     */
    public $userId;

    /**
     * @var string
     */
    public $uuid;

    /**
     * @var string
     */
    public $token;

    /**
     * @var string
     */
    public $platform;

    /**
     * @var integer
     */
    public $activityTime;

    /**
     * @var integer
     */
    public $properties;

    /**
     * @var integer
     */
    public $addTime;

    public function getProperties()
    {
        if ( empty($this->properties) )
        {
            return array();
        }

        return json_decode($this->properties, true);
    }

    public function setProperties( array $props )
    {
        $this->properties = json_encode($props);
    }

}
