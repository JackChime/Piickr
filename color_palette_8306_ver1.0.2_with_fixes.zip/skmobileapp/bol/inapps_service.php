<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */

use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;


class SKMOBILEAPP_BOL_InappsService extends SKMOBILEAPP_BOL_Service
{
    const GATEWAY_KEY = 'skmobileapp';

    use OW_Singleton;
    
    public function getMemberships($userId)
    {
        if ( !OW::getPluginManager()->isPluginActive('membership') )
        {
            throw new BadRequestHttpException('Membership plugin not activated');
        }

        $membershipService = MEMBERSHIP_BOL_MembershipService::getInstance();
        $authService = BOL_AuthorizationService::getInstance();

        $accTypeName = BOL_UserService::getInstance()->findUserById($userId)->getAccountType();
        $accType = BOL_QuestionService::getInstance()->findAccountTypeByName($accTypeName);

        $mTypes = $membershipService->getTypeList($accType->id);

        /* @var $defaultRole BOL_AuthorizationRole */
        $defaultRole = $authService->getDefaultRole();

        /* @var $default MEMBERSHIP_BOL_MembershipType */
        $default = new MEMBERSHIP_BOL_MembershipType();
        $default->roleId = $defaultRole->id;

        $mTypes = array_merge(array($default), $mTypes);

        $userMembership = $membershipService->getUserMembership($userId);
        $userRoleIds = array($defaultRole->id);

        if ( $userMembership )
        {
            $type = $membershipService->findTypeById($userMembership->typeId);
            if ( $type )
            {
                $userRoleIds[] = $type->roleId;
            }
        }

        $permissions = $authService->getPermissionList();

        $perms = array();
        foreach ( $permissions as $permission )
        {
            /* @var $permission BOL_AuthorizationPermission */
            $perms[$permission->roleId][$permission->actionId] = true;
        }

        $exclude = $membershipService->getUserTrialPlansUsage($userId);

        $mPlans = $membershipService->getTypePlanList($exclude);

        $plansNumber = 0;
        $mTypesPermissions = array();
        foreach ( $mTypes as $membership )
        {
            $mId = $membership->id;
            $plans = isset($mPlans[$mId]) ? $mPlans[$mId] : null;
            $data = array(
                'id' => $mId,
                'title' => $membershipService->getMembershipTitle($membership->roleId),
                'roleId' => $membership->roleId,
                'permissions' => isset($perms[$membership->roleId]) ? $perms[$membership->roleId] : null,
                'current' => in_array($membership->roleId, $userRoleIds),
                'plans' => $plans
            );
            $plansNumber += count($plans);
            $mTypesPermissions[] = $data;
        }
        return $mTypesPermissions;
    }
    
    public function createAndDeliver($result, $data, $userId)
    {
        $billingService = BOL_BillingService::getInstance();

        $productId = $data['originalProductId'];
        $purchaseTime = $result['purchaseTime'];
        $orderId = $result['orderId'];
        $purchaseToken = $result['purchaseToken'];

        if ($data['platform'] == 'android')
        {
            $product = $this->findProductByItunesProductId($productId);
        }
        else
        {
            $product = $this->findProductByItunesProductId($productId);
        }

        if ( !isset($product['pluginKey']) )
        {
            throw new BadRequestHttpException('Product not found');
        }

        // sale object
        $sale = new BOL_BillingSale();
        $sale->pluginKey = $product['pluginKey'];
        $sale->entityDescription = $product['entityDescription'];
        $sale->entityKey = $product['entityKey'];
        $sale->entityId = $product['entityId'];
        $sale->price = $product['price'];
        $sale->period = $product['period'];
        $sale->userId = $userId;
        $sale->recurring = $product['recurring'];
        $sale->periodUnits = ( isset($product['periodUnits']) ? $product['periodUnits'] : null );

        $dateProduct = array(
            'userId' => $userId,
            'username' => BOL_UserService::getInstance()->getUserName($userId),
            'pluginKey' => $product['pluginKey'],
            'entityDescription' => $product['entityDescription']
        );

        if ( isset($product['membershipTitle']) )
        {
            $dateProduct['membershipTitle'] = $product['membershipTitle'];
        }

        $saleId = $billingService->initSale($sale, self::GATEWAY_KEY);


        $sale = $billingService->getSaleById($saleId);

        $sale->timeStamp = $purchaseTime / 1000;
        $sale->transactionUid = $orderId;
        $sale->extraData = json_encode(array(
            'orderId' => $orderId,
            'purchaseToken' => $purchaseToken,
            'extra' => $data['transactionData']
        ));

        BOL_BillingSaleDao::getInstance()->save($sale);

        $productAdapter = null;
        switch ( $sale->pluginKey )
        {
            case 'membership':
                $productAdapter = new MEMBERSHIP_CLASS_MembershipPlanProductAdapter();
                break;

            case 'usercredits':
                $productAdapter = new USERCREDITS_CLASS_UserCreditsPackProductAdapter();
                break;
        }

        return $billingService->deliverSale($productAdapter, $sale);
    }

    public function findProductByAndroidProductId( $productId )
    {
        $entityKey = strtolower(substr($productId, 0, strrpos($productId, '_')));
        $entityId = (int) substr($productId, strrpos($productId, '_') + 1);

        if ( !strlen($entityKey) || !$productId )
        {
            return null;
        }

        $pm = OW::getPluginManager();
        $return = array();

        switch ( $entityKey )
        {
            case 'membership_plan':
                if ( !$pm->isPluginActive('membership') )
                {
                    return null;
                }

                $membershipService = MEMBERSHIP_BOL_MembershipService::getInstance();

                $plan = $membershipService->findPlanById($entityId);
                if ( !$plan )
                {
                    return null;
                }

                $type = $membershipService->findTypeById($plan->typeId);
                $return['pluginKey'] = 'membership';
                $return['entityDescription'] = $membershipService->getFormattedPlan(
                    $plan->price, $plan->period, $plan->recurring,
                    null, $plan->periodUnits);
                $return['membershipTitle'] = $membershipService->getMembershipTitle($type->roleId);
                $return['price'] = floatval($plan->price);
                $return['period'] = $plan->period;
                $return['recurring'] = $plan->recurring;
                $return['periodUnits'] = $plan->periodUnits;

                break;

            case 'user_credits_pack':
                if ( !$pm->isPluginActive('usercredits') )
                {
                    return null;
                }

                $creditsService = USERCREDITS_BOL_CreditsService::getInstance();

                $pack = $creditsService->findPackById($entityId);
                if ( !$pack )
                {
                    return null;
                }

                $return['pluginKey'] = 'usercredits';
                $return['entityDescription'] = $creditsService->getPackTitle($pack->price, $pack->credits);
                $return['price'] = floatval($pack->price);
                $return['period'] = 30;
                $return['recurring'] = 0;

                break;
        }

        $return['entityKey'] = $entityKey;
        $return['entityId'] = $entityId;

        return $return;
    }

    public function findProductByItunesProductId( $productId )
    {
        $entityKey = strtolower(substr($productId, 0, strrpos($productId, '_')));
        $entityId = (int) substr($productId, strrpos($productId, '_') + 1);

        if ( !strlen($entityKey) || !$productId )
        {
            return null;
        }

        $pm = OW::getPluginManager();
        $return = array();

        switch ( $entityKey )
        {
            case 'membership_plan':
                if ( !$pm->isPluginActive('membership') )
                {
                    return null;
                }

                $membershipService = MEMBERSHIP_BOL_MembershipService::getInstance();

                $plan = $membershipService->findPlanById($entityId);
                if ( !$plan )
                {
                    return null;
                }

                $type = $membershipService->findTypeById($plan->typeId);

                $return['pluginKey'] = 'membership';
                $return['entityDescription'] = $membershipService->getFormattedPlan(
                    $plan->price, $plan->period, $plan->recurring,
                    null, $plan->periodUnits
                );
                $return['membershipTitle'] = $membershipService->getMembershipTitle($type->roleId);

                $return['price'] = floatval($plan->price);
                $return['period'] = $plan->period;
                $return['recurring'] = $plan->recurring;

                break;

            case 'user_credits_pack':
                if ( !$pm->isPluginActive('usercredits') )
                {
                    return null;
                }

                $creditsService = USERCREDITS_BOL_CreditsService::getInstance();

                $pack = $creditsService->findPackById($entityId);
                if ( !$pack )
                {
                    return null;
                }

                $return['pluginKey'] = 'usercredits';
                $return['entityDescription'] = $creditsService->getPackTitle($pack->price, $pack->credits);
                $return['price'] = floatval($pack->price);
                $return['period'] = 30;
                $return['recurring'] = 0;

                break;
        }

        $return['entityKey'] = $entityKey;
        $return['entityId'] = $entityId;

        return $return;
    }

    public function validateAndroidPurchase($data)
    {
        $transactionData = $data['transactionData'];
        $receipt = json_decode($transactionData['receipt'], 1);

        $validator = new SKMOBILEAPP_CLASS_AndroidReceiptValidator(OW::getConfig()->getValue('skmobileapp', 'inapps_apm_key'));

        $result = array(
            "status" => $validator->validateReceipt($transactionData['signature'], $transactionData['receipt']),
            "productId" => $transactionData['productId'],
            "purchaseTime" => $receipt['purchaseTime'],
            "orderId" => isset($receipt['orderId']) ? $receipt['orderId'] : 'test_' . $receipt['purchaseTime'],
            "purchaseToken" => $receipt['purchaseToken'],
        );
        return $result;
    }

    public function validateIOSPurchase($data)
    {
        $mode = OW::getConfig()->getValue('skmobileapp', 'inapps_ios_test_mode') ? 'test' : 'live';
        $sharedSecret = OW::getConfig()->getValue('skmobileapp', 'inapps_itunes_shared_secret');
        $validator = new SKMOBILEAPP_CLASS_ItunesReceiptValidator($mode, $sharedSecret);

        $transactionData = $data['transactionData'];

        $result = $validator->validateReceipt($transactionData['receipt']);

        if ( isset($result['status']) && $result['status'] == 0 )
        {
            $transactionId = $transactionData['transactionId'];
            foreach ($result['receipt']['in_app'] as $value)
            {
                if ($value['transaction_id'] == $transactionId)
                {
                    return array(
                        "status" => true,
                        "productId" => $value["product_id"],
                        "purchaseTime" => $value["purchase_date_ms"],
                        "orderId" => $value["transaction_id"],
                        "purchaseToken" => null
                    );
                }
            }
        }

        return false;
    }

    public function getUserMembership($userId)
    {
        if ( !OW::getPluginManager()->isPluginActive('membership') )
        {
            throw new BadRequestHttpException('Membership plugin not activated');
        }
        return MEMBERSHIP_BOL_MembershipService::getInstance()->getUserMembership($userId);
    }

}
