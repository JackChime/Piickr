<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */

class SKMOBILEAPP_BOL_BookmarksService extends SKMOBILEAPP_BOL_Service
{
    use OW_Singleton;


    /**
     * Get marked list by user id
     *
     * @param integer $userId
     * @param array $markIdList
     * @return array
     */
    public function getMarkedListByUserId( $userId, $markIdList = [])
    {
        $bookmarksDao = BOOKMARKS_BOL_MarkDao::getInstance();

        if ( $markIdList )
        {
            $sql = 'SELECT `id`, `' . BOOKMARKS_BOL_MarkDao::USER_ID . '`, `' . BOOKMARKS_BOL_MarkDao::MARK_USER_ID . '`
                FROM `' . $bookmarksDao->getTableName() . '`
                WHERE `' . BOOKMARKS_BOL_MarkDao::USER_ID . '` = :userId AND
                    `' . BOOKMARKS_BOL_MarkDao::MARK_USER_ID . '` IN (' . implode(',', array_map('intval', $markIdList)) . ');';
        }
        else {
            $sql = 'SELECT `id`, `' . BOOKMARKS_BOL_MarkDao::USER_ID . '`, `' . BOOKMARKS_BOL_MarkDao::MARK_USER_ID . '`
                FROM `' . $bookmarksDao->getTableName() . '`
                WHERE `' . BOOKMARKS_BOL_MarkDao::USER_ID . '` = :userId';
        }

        $result = OW::getDbo()->queryForList($sql, [
            'userId' => $userId
        ]);

        $out = [];
        foreach ( $result as $bookmark )
        {
            $out[] = [
                'id' => (int) $bookmark['id'],
                'userId' => (int) $bookmark[BOOKMARKS_BOL_MarkDao::USER_ID],
                'markUserId' => (int) $bookmark[BOOKMARKS_BOL_MarkDao::MARK_USER_ID]
            ];
        }

        return $out;
    }
}
