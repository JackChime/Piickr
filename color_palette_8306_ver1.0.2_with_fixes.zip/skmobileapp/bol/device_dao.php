<?php

/**
 * Data Access Object for `skmobileapp_devices` table.
 *
 * @author Sergei Kiselev <arrserg@gmail.com>
 * @package ow.plugin.skmobileapp.bol
 * @since 1.7.5
 */
class SKMOBILEAPP_BOL_DeviceDao extends OW_BaseDao
{
    /**
     * Singleton instance.
     *
     * @var SKMOBILEAPP_BOL_DeviceDao
     */
    private static $classInstance;

    /**
     * Constructor.
     */
    protected function __construct()
    {
        parent::__construct();
    }

    /**
     * Returns an instance of class.
     *
     * @return SKMOBILEAPP_BOL_DeviceDao
     */
    public static function getInstance()
    {
        if ( self::$classInstance === null )
        {
            self::$classInstance = new self();
        }

        return self::$classInstance;
    }

    /**
     * @see OW_BaseDao::getDtoClassName()
     *
     */
    public function getDtoClassName()
    {
        return 'SKMOBILEAPP_BOL_Device';
    }

    /**
     * @see OW_BaseDao::getTableName()
     *
     */
    public function getTableName()
    {
        return OW_DB_PREFIX . 'skmobileapp_devices';
    }

    /**
     * Returns device by uuid and userId
     *
     * @param string $userId
     * @param string $uuid
     * @return SKMOBILEAPP_BOL_Device
     */
    public function findByUserIdAndUuid( $userId, $uuid )
    {
        $example = new OW_Example();
        $example->andFieldEqual('userId', $userId);
        $example->andFieldEqual('uuid', $uuid);

        return $this->findObjectByExample($example);
    }

    /**
     * Returns device by userId
     *
     * @param string $userId
     * @return SKMOBILEAPP_BOL_Device
     */
    public function findByUserId( $userId )
    {
        $example = new OW_Example();
        $example->andFieldEqual('userId', $userId);

        return $this->findListByExample($example);
    }

    /**
     * Remove user devices
     *
     * @param integer $userId
     */
    public function removeUserDevices( $userId )
    {
        $example = new OW_Example();
        $example->andFieldEqual('userId', $userId);

        $this->deleteByExample($example);
    }

    /**
     * Remove old devices
     *
     */
    public function removeOldDevices()
    {
        $example = new OW_Example();
        $example->andFieldLessThan('activityTime', time() - 60 * 60 * 24 * 30);

        $this->deleteByExample($example);
    }

    /**
     * Remove ios devices
     *
     */
    public function removeIOSDevices()
    {
        $example = new OW_Example();
        $example->andFieldEqual('platform', 'iOS');

        $this->deleteByExample($example);
    }

}
