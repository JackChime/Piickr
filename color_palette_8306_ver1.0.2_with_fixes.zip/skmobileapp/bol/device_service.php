<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */

class SKMOBILEAPP_BOL_DeviceService
{
    use OW_Singleton;

    /**
     * @var SKMOBILEAPP_BOL_DeviceDao
     */
    private $deviceDao;

    /**
     * Class constructor
     *
     */
    private function __construct()
    {
        $this->deviceDao = SKMOBILEAPP_BOL_DeviceDao::getInstance();
    }

    /**
     * Create device
     *
     * @param array $data
     * @return  SKMOBILEAPP_BOL_Device
     */
    public function createDevice( $data )
    {
        $device = new SKMOBILEAPP_BOL_Device();
        $device->userId = $data['userId'];
        $device->uuid = $data['uuid'];
        $device->token = $data['token'];
        $device->platform = $data['platform'];
        $device->activityTime = time();
        $device->addTime = time();
        $device->setProperties($data['properties']);
        $this->deviceDao->save($device);
        return $device;
    }

    /**
     * Update device
     *
     * @param int $id
     * @param array $data
     * @return  SKMOBILEAPP_BOL_Device
     */
    public function updateDevice( $id, $data )
    {
        $device = $this->findById($id);
        $device->token = $data['token'];
        $device->activityTime = time();
        $this->deviceDao->save($device);
        return $device;
    }

    /**
     * Finds device by id
     *
     * @param int $id
     * @return OW_Entity|SKMOBILEAPP_BOL_Device
     */
    public function findById( $id )
    {
        return $this->deviceDao->findById($id);
    }

    /**
     * Finds device by userId
     *
     * @param int $userId
     * @return OW_Entity|SKMOBILEAPP_BOL_Device
     */
    public function findByUserId( $userId )
    {
        return $this->deviceDao->findByUserId($userId);
    }

    /**
     * Finds device by userId and uuid
     *
     * @param int $userId
     * @param int $uuid
     * @return OW_Entity|SKMOBILEAPP_BOL_Device
     */
    public function findUserDevice( $userId, $uuid )
    {
        return $this->deviceDao->findByUserIdAndUuid($userId, $uuid);
    }

    /**
     * Remove old devices
     *
     */
    public function removeOldDevices()
    {
        return $this->deviceDao->removeOldDevices();
    }

    /**
     * Remove ios devices
     *
     */
    public function removeIOSDevices()
    {
        return $this->deviceDao->removeIOSDevices();
    }
}
