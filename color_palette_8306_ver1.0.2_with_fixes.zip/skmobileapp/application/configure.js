const configure = require('./scripts/configure');

configure();