import { Component, Input, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { EventEmitter, Output } from '@angular/core';

@Component({
    selector: 'user-image',
    templateUrl: './index.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ImageComponent {
    @Input() public url: string;
    @Input() public showSpinner: boolean = false;
    @Output() loaded = new EventEmitter();

    private isImageLoaded: boolean = false;

    /**
     * Constructor
     */
    constructor(private ref: ChangeDetectorRef) {}

    /**
     * Image loaded
     */
    imageLoaded(): void {
        this.loaded.emit();
        this.isImageLoaded = true;
        this.ref.markForCheck();
    }

    /**
     * Image not loaded
     */
    imageNotLoaded(): void {
        this.url = ''; // use no image
        this.ref.markForCheck();
    }
}
