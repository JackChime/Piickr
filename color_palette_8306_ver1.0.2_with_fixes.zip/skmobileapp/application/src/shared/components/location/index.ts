import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'user-location',
    templateUrl: './index.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class LocationComponent {
    @Input() public distance: number;
    @Input() public unit: string;
}
