// services
import { PluginsService } from '../../services/plugins/index';
import { DataStore } from 'js-data';

export class BaseComponentMixin
{
    public static plugins: PluginsService;
    public static api: DataStore;

    private static readonly SEARCH_MODE_TINDER: string = 'tinder';
    private static readonly SEARCH_MODE_BROWSE: string = 'browse';
    private static readonly SEARCH_MODE_BOTH: string = 'both';

    /**
     * Is chat conversation exists
     */
    isChatConversationExists(userId: number): boolean {
        let conversation: any[] = BaseComponentMixin.api.filter('conversations', {
            where: {
                opponentId: userId
            }});

        return conversation.length > 0;
    }

    /**
     * Is plugin active
     */
    isPluginActive(pluginKey: string|string[]): boolean {
        return BaseComponentMixin.plugins.isPluginActive(pluginKey);
    }

    /**
     * Is tinder search mode
     */
    isTinderSearchMode(): boolean {
        return BaseComponentMixin.api.get('configs', 'searchMode').value == BaseComponentMixin.SEARCH_MODE_TINDER;
    }

    /**
     * Is browse search mode
     */
    isBrowseSearchMode(): boolean {
        return BaseComponentMixin.api.get('configs', 'searchMode').value == BaseComponentMixin.SEARCH_MODE_BROWSE;
    }

    /**
     * Is both search mode
     */
    isBothSearchMode(): boolean {
        return BaseComponentMixin.api.get('configs', 'searchMode').value == BaseComponentMixin.SEARCH_MODE_BOTH;
    }

    /**
     * Is tinder search allowed
     */
    isTinderSearchAllowed(): boolean {
        let searchMode: string =  BaseComponentMixin.api.get('configs', 'searchMode').value;

        return searchMode == BaseComponentMixin.SEARCH_MODE_TINDER || searchMode == BaseComponentMixin.SEARCH_MODE_BOTH;
    }

    /**
     * Is browse search allowed
     */
    isBrowseSearchAllowed(): boolean {
        let searchMode: string =  BaseComponentMixin.api.get('configs', 'searchMode').value;

        return searchMode == BaseComponentMixin.SEARCH_MODE_BROWSE || searchMode == BaseComponentMixin.SEARCH_MODE_BOTH;
    }

    /**
     * Get toast duration
     */
    toastDuration(): number {
        return BaseComponentMixin.api.get('configs', 'toastDuration').value;
    }
}
