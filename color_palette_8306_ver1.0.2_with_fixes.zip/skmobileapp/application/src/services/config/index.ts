import { Injectable } from '@angular/core';

var configFile = require('../../../application.config.json');

// services
import { StorageService } from '../../services/storage/index';

@Injectable()
export class ConfigService {
    protected baseUri: string;
    protected baseApiUri: string;

    /**
     * Constructor
     */
    constructor(private storage: StorageService) {
        this.baseUri = '/skmobileapp/';
        this.baseApiUri = this.baseUri + 'api';
    }

    /**
     * Get config
     */
    public getConfig(configName: string): string {
        let value: string = configFile[configName];

        return value;
    }

    /**
     * Get generic api url
     */
    public getGenericApiUrl(): string {
        if (!this.getConfig('serverUrl')) { // check custom server url
            return this.storage.getValue('server-url');
        }
    }

    /**
     * Set generic api url
     */
    public setGenericApiUrl(url: string): void {
        this.storage.setValue('server-url', url);
    }

    /**
     * Get api uri
     */
    public getApiUri(): string {
        return this.baseApiUri;
    }

    /**
     * Get api url
     */
    public getApiUrl(): string {
        let serverUrl: string = configFile['serverUrl'] // check custom server url
            ? configFile['serverUrl']
            : this.getGenericApiUrl();

        if (serverUrl) {
            return serverUrl + this.getApiUri();
        }
    }
}


