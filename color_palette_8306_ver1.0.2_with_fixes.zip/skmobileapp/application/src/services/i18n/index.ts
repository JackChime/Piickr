import { MissingTranslationHandler, MissingTranslationHandlerParams } from 'ng2-translate/ng2-translate';

let fallbackLangs = {
    app_error_page_header: 'Oops. Something went wrong.',
    app_error_page_description: 'Please try again later',
    ok: 'OK',
    site_address_input: '://Site URL',
    site_address_input_require_error: 'You have to enter your site address',
    no_internet: 'No internet connection',
    site_address_error: 'Invalid site url',
    error_occurred: 'Error Occurred',
    next: 'Next',
    change_site_url_page_header: 'Change site url'
};

export class CustomMissingTranslationHandler implements MissingTranslationHandler {
    handle(params: MissingTranslationHandlerParams) {
        console.warn(`Translation is missing for key: ${params.key}`);

        if (fallbackLangs[params.key]) {
            return fallbackLangs[params.key];
        }
    }
}
