import { Injectable } from '@angular/core';
import { InAppPurchase } from '@ionic-native/in-app-purchase';
import { Platform } from 'ionic-angular';
import { parse as urlParse } from 'url';

import { SecureHttpService } from '../../services/http/index';
import { ConfigService } from '../../services/config/index';

@Injectable()
export class InAppsService
{
    /**
     * Constructor
     */
    constructor(
        private iap: InAppPurchase,
        private http: SecureHttpService,
        private config: ConfigService,
        private platform: Platform
    ){}


    /**
     * Add prefix to product id
     */
    addPrefix(productId: string): string {
        let prefix: string = '';

        if (this.config.getConfig('universal') == '1') {
            let parsedUrl = urlParse(this.config.getApiUrl());

            prefix = parsedUrl.host.replace('www.', '').replace(/\./g, '') + '_';
        }

        return prefix + productId;
    }

    /**
     * Get products
     */
    getProducts(data: any[]): Promise<any> {
        let ids: string[] = [];

        for (let i in data) {
            let processedProductId = this.addPrefix(data[i]['productId']);

            // backward compatibility
            ids.push(processedProductId);
            ids.push(processedProductId.toLowerCase());
            ids.push(processedProductId.toUpperCase());
        }

        return this.iap.getProducts(ids);
    }

    /**
     * Buy product
     */
    async buyProduct(definedProductId: string, originalProductId: string): Promise<any>{
        try {
            let data = await this.iap.buy(definedProductId);
            let validationResult = await this.validatePurchase(data, originalProductId);

            if ((validationResult.id != -1) && this.platform.is('android')) {
                await this.iap.consume(data['productType'], data['receipt'], data['signature'])
            }

            return validationResult;
        } catch (e){}
    }

    private validatePurchase(data: any, originalProductId: string): Promise<any>{
        let platform = 'unknown';
        if (this.platform.is('android')){
            platform = 'android';
        } else if (this.platform.is('ios')){
            platform = 'ios';
        }
        return this.http.post(this.config.getApiUrl() + '/inapps/', JSON.stringify({
            "platform": platform,
            "transactionData": data,
            "originalProductId": originalProductId
        }))
            .map(res => res.json())
            .toPromise();
    }
}
