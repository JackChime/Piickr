
export const HotListUsers = {
    name: 'HotListUsers',
    endpoint: 'hotlist-users'
};
