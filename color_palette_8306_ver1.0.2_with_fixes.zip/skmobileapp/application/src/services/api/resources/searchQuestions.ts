
export const SearchQuestions = {
    name: 'SearchQuestions',
    endpoint: 'search-questions',
    relations: {
    }
};
