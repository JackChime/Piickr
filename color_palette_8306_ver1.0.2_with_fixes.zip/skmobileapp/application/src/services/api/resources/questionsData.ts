
export const QuestionsData = {
    name: 'QuestionsData',
    endpoint: 'questions-data',
    relations: {
    }
};
