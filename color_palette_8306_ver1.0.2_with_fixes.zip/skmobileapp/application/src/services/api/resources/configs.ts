
export const Configs = {
    name: 'Configs',
    endpoint: 'configs',
    relations: {
    }
};
