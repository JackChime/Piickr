
export const JoinQuestions = {
    name: 'JoinQuestions',
    endpoint: 'join-questions',
    relations: {
    }
};
