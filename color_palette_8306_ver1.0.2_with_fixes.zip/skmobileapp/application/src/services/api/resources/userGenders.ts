
export const UserGenders = {
    name: 'UserGenders',
    endpoint: 'user-genders',
    relations: {
    }
};
