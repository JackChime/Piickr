
export const Conversations = {
    name: 'Conversations',
    endpoint: 'mailbox/conversations'
};
