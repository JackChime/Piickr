
export const EditQuestions = {
    name: 'EditQuestions',
    endpoint: 'edit-questions',
    relations: {
    }
};
