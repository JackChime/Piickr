
export const Guests = {
    name: 'Guests',
    endpoint: 'guests'
};
