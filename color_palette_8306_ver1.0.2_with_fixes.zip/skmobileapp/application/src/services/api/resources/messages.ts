
export const Messages = {
    name: 'Messages',
    endpoint: 'mailbox/messages'
};
