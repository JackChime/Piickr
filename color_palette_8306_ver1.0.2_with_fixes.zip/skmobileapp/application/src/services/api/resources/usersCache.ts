
export const UsersCache = {
    name: 'UsersCache',
    endpoint: 'usersCache',
    relations: {
    }
};
