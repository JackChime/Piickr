
export const MatchedUsers = {
    name: 'MatchedUsers',
    endpoint: 'matched-users'
};
