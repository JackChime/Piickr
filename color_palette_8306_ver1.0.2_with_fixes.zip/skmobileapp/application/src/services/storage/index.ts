import { Injectable } from '@angular/core';

@Injectable()
export class StorageService
{
    /**
     * Get value
     */
    getValue(name: string, defaultValue: any = null): any {
        let value: any = JSON.parse(localStorage.getItem(name));

        if (value === null && defaultValue !== null) {
            return defaultValue;
        }

        return value;
    }

    /**
     * Set value
     */
    setValue(name: string, value: any): void {
        localStorage.setItem(name, JSON.stringify(value));
    }

    /**
     * Remove value
     */
    removeValue(name: string): void {
        localStorage.removeItem(name);
    }

    /**
     * Remove all values
     */
    removeAllValues(): void {
        localStorage.clear();
    }
}
