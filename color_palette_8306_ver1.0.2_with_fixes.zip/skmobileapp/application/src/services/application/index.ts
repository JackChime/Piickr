import { Injectable, Inject, forwardRef } from '@angular/core';
import { DataStore } from 'js-data';
import { TranslateService } from 'ng2-translate';
import { Platform, Config as AppConfig, Events } from 'ionic-angular';
import 'rxjs/add/operator/toPromise';

// import services
import { SecureHttpService } from '../../services/http/index';
import { ConfigService } from '../../services/config/index';
import { AdMobService } from '../../services/admob/index';
import { PushNotificationsService } from '../../services/push/index';
import { StorageService } from '../../services/storage/index';

@Injectable()
export class ApplicationService {
    private appLanguage = 'en';
    private appLocation: {latitude: number, longitude: number} = null;
    private http: SecureHttpService;
    private pushNotifications: PushNotificationsService;
    private isApplicationDependenciesLoaded: boolean = false;

    /**
     * Constructor
     */
    constructor(
        @Inject(forwardRef(() => PushNotificationsService)) pushNotifications: PushNotificationsService,
        private events: Events,
        private adMobService: AdMobService,
        private storage: StorageService,
        private platform: Platform,
        private appConfig: AppConfig,
        private translate: TranslateService,
        private api: DataStore,
        @Inject(forwardRef(() => SecureHttpService)) http: SecureHttpService,
        private config: ConfigService)
    {
        this.http = http;
        this.pushNotifications = pushNotifications;
    }

    /**
     * Is application ready
     */
    isApplicationReady(): boolean {
        return this.isApplicationDependenciesLoaded;
    }

    /**
     * Set app location
     */
    setAppLocation(latitude: number, longitude: number): void {
        this.appLocation = {
            latitude: latitude,
            longitude: longitude,
        };

        this.events.publish('location:updated');
    }

    /**
     * Get app location
     */
    getAppLocation(): {latitude: number, longitude: number} {
        return this.appLocation;
    }

    /**
     * Set app language
     */
    setAppLanguage(language: string): void {
        this.appLanguage = language;
    }

    /**
     * Get app language
     */
    getAppLanguage(): string {
        return this.appLanguage;
    }

    /**
     * Get app setting
     */
    getAppSetting(name: string, defaultValue: any = null): any {
        return this.storage.getValue(`app_setting_${name}`, defaultValue);
    }

    /**
     * Set app setting
     */
    setAppSetting(name: string, value: any): void {
        this.storage.setValue(`app_setting_${name}`, value);
    }

    /**
     * Load dependencies
     */
    loadDependencies(clearOldData: boolean = true): Promise<any> {
        this.isApplicationDependenciesLoaded = false;

        // clear old data
        if (clearOldData) {
            this.api.removeAll('configs');
            this.translate.resetLang(this.appLanguage);
        }

        let promises = [];

        // load configs
        promises.push(this.api.findAll('configs', {}, {force: true}));

        // load translations
        promises.push(this.http.get(this.config.getApiUrl() + '/i18n/' + this.appLanguage + '/')
            .toPromise()
            .then(res => this.translate.setTranslation(this.appLanguage, res.json()))
        );

        return new Promise((resolve, reject) => {
            // load dependencies
            Promise.all(promises).then(() => {
                // init translations
                this.translate.use(this.appLanguage);

                // translate navigation items
                this.appConfig.set('backButtonText', this.translate.instant('back'));

                if (this.platform.is('cordova')) {
                    // init admob banners
                    this.adMobService.init();

                    // init push notifications
                    this.pushNotifications.init(this.appLanguage);
                }

                this.isApplicationDependenciesLoaded = true;
                resolve();
            }).catch(() => {
                reject();
            });
        });
    }
}
