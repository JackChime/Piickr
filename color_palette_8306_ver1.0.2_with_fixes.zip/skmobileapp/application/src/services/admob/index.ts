import { Injectable } from '@angular/core';
import { App, Events } from 'ionic-angular';
import { AdMobFree, AdMobFreeBannerConfig } from '@ionic-native/admob-free';
import { DataStore } from 'js-data';

import { PermissionsService } from '../../services/permissions/index';

@Injectable()
export class AdMobService
{
    private bannerCreated: boolean = false;
    private eventSubscribed: boolean = false;
    private isBannerVisible: boolean = false;
    private lastViewName: string = '';
    private configsUpdatedHandler: () => void;
    private permissionsUpdatedHandler: () => void;

    /**
     * Constructor
     */
    constructor(
        private api: DataStore,
        private app: App,
        private adMob: AdMobFree,
        private events: Events,
        private permissions: PermissionsService
    ) {
        this.configsUpdatedHandler = (): void => {
            if (this.config.enabled){
                this.checkView(this.lastViewName);
            } else {
                this.hideBanner();
            }
        };

        this.permissionsUpdatedHandler = (): void => {
            if (this.permissions.isActionAllowed('ads_hide_ads'))
            {
                this.hideBanner();
            } else {
                this.checkView(this.lastViewName);
            }
        };

    }

    /**
     * Init
     */
    init(): void {
        if (this.bannerCreated) {
            this.hideBanner();
            this.adMob.banner.remove()
        }

        let nav = this.app.getRootNav();
        this.bannerCreated = false;

        this.events.subscribe('permissions:updated', this.permissionsUpdatedHandler);
        this.events.subscribe('configs:updated', this.configsUpdatedHandler);

        if (!this.eventSubscribed) {
            nav.viewDidEnter.subscribe((view) => {
                this.checkView(view.pageRef().nativeElement.tagName);
            });

            this.eventSubscribed = true;
        }
    }

    /**
     * Check view
     */
    async checkView(viewName): Promise<any> {
        this.lastViewName = viewName;
        if (this.config.enabled && this.config.adId) {
            if (!this.bannerCreated) {
                await this.createBanner();

                this.bannerCreated = true;
                this.checkView(viewName);

                return;
            }

            if (this.config.availableViews.includes(viewName)) {
                this.showBanner();
                return;
            }

            this.hideBanner();

            return;
        }
    }

    /**
     * Create banner
     */
    private createBanner(): Promise<any> {
        let config: AdMobFreeBannerConfig = {
            id: this.config.adId,
            overlap: false,
            autoShow: false
        };

        this.adMob.banner.config(config);
        return this.adMob.banner.prepare();
    }

    /**
     * Show banner
     */
    private showBanner(): void {
        if (!this.isBannerVisible) {
            this.adMob.banner.show();
            this.isBannerVisible = true;
        }
    }

    /**
     * Hide banner
     */
    private hideBanner(): void {
        if (this.isBannerVisible) {
            this.adMob.banner.hide();
            this.isBannerVisible = false;
        }
    }

    /**
     * Config
     */
    private get config(): any {
        return this.api.get('configs', 'adMobConfig').value;
    }
}
