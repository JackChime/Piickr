import { Injectable } from '@angular/core';
import { DataStore } from 'js-data';

@Injectable()
export class PluginsService {
    /**
     * Constructor
     */
    constructor(private api: DataStore) {}

    /**
     * Is plugin active
     *
     * @param pluginKey
     */
    isPluginActive(pluginKey: string|string[]): boolean {
        let allActivePlugins: string[] = this.api.get('configs', 'activePlugins').value;

        if (Array.isArray(pluginKey)) {
            let isActive: boolean = false;

            pluginKey.forEach((key) => {
                if (allActivePlugins.includes(key)) {
                    isActive = true;
                }
            });

            return isActive;
        }

        return allActivePlugins.includes(pluginKey);
    }
}
