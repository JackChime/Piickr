import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavController, NavParams, LoadingController, Events } from 'ionic-angular';
import { DataStore } from 'js-data';

import { SecureHttpService } from '../../../../../services/http/index';
import { ConfigService } from '../../../../../services/config/index';
import { InAppsService} from '../../../../../services/inapps/index';
import { ApiUtilsService } from '../../../../../services/api/utils';
import { AuthService } from '../../../../../services/auth/index';

import { DashboardPage } from '../../../../../pages/dashboard/index';

// mixins
import { Mixin } from '../../../../../mixins/index';
import { BaseComponentMixin } from '../../../../../mixins/baseComponent/index';

@Component({
    selector: 'membership',
    templateUrl: 'index.html',
})
@Mixin([BaseComponentMixin])

export class ViewMembershipComponent implements OnInit, OnDestroy {
    isPluginActive: (pluginKey: string|string[]) => boolean;

    private membership: any = {};
    private membershipId: any = null;

    private configsUpdatedHandler: () => void;

    /**
     * Constructor
     */
    constructor(
        private events: Events,
        private api: DataStore,
        private apiUtils: ApiUtilsService,
        private auth: AuthService,
        private config: ConfigService,
        private http: SecureHttpService,
        private iaps: InAppsService,
        private loadingCtrl: LoadingController,
        private nav: NavController,
        private navParams: NavParams)
    {
        // -- init callbacks --//

        // configs updated handler
        this.configsUpdatedHandler = (): void => {
            // redirect to dashboard
            if (!this.isPluginActive('membership')) {
                this.nav.setRoot(DashboardPage);

                return;
            }
        };
    }

    get currency(): string {
        return this.api.get('configs', 'billingCurrency').value;
    }

    /**
     * Component init
     */
    ngOnInit(): void {
        this.membershipId = this.navParams.get('mewmbershipId');
        this.events.subscribe('configs:updated', this.configsUpdatedHandler);

        this.loadMembership();
    }

    /**
     * Component destroy
     */
    ngOnDestroy(): void {
        this.events.unsubscribe('configs:updated', this.configsUpdatedHandler);
    }

    async loadMembership(): Promise<any> {
        let loader = this.loadingCtrl.create();
        await loader.present();

        try{
            let data = await this.http.get(this.config.getApiUrl() + '/memberships/' + this.membershipId + '/')
                .map(response => response.json())
                .toPromise();

            let registeredProducts: any[] = await this.iaps.getProducts(data['plans']);

            // sync plans
            data['plans'] = data['plans'].filter((el: any) => {
                // process products from google or apple store
                for (let key in registeredProducts) {
                    let processedProduct: RegExp = new RegExp(registeredProducts[key]['productId'], 'i');

                    if (processedProduct.test(this.iaps.addPrefix(el.productId))) {
                        el.definedProductId = registeredProducts[key]['productId'];

                        return true;
                    }
                }

                return false;
            });

            this.membership = data;
        } catch (e){}

        loader.dismiss();
    }

    /**
     * Buy product
     */
    async buyProduct(definedProductId: string, originalProductId: string): Promise<any> {
        let loader = this.loadingCtrl.create();

        try {
            await loader.present();
            let result = await this.iaps.buyProduct(definedProductId, originalProductId);

            loader.dismiss();

            if (result.id != -1) {
                this.apiUtils.clearUserData(this.auth.getUserId(), true);
                this.nav.push(DashboardPage)
            }
        }
        catch (e) {
            loader.dismiss();
        }
    }
}
