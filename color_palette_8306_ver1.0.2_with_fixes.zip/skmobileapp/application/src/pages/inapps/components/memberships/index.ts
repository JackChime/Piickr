import { NavController, LoadingController, ModalController } from 'ionic-angular';

import { Component } from '@angular/core';
import { SecureHttpService } from '../../../../services/http/index';
import { ConfigService } from '../../../../services/config/index';
import { TranslateService } from 'ng2-translate';

import { ViewMembershipComponent } from './viewMembership/index'

// pages
import { CustomPageComponent } from '../../../../shared/components/customPage/index';

@Component({
    selector: 'memberships',
    templateUrl: 'index.html'
})

export class MembershipsComponent {

    private memberships: any = [];
    private currentMembership: string = '';
    private isRecurringPlansAvailable: boolean = false;

    /**
     * Constructor
     */
    constructor(
        private translate: TranslateService,
        private modalCtrl: ModalController,
        private config: ConfigService,
        private http: SecureHttpService,
        private loadingCtrl: LoadingController,
        private nav: NavController
    ){
        this.loadMemberships()
    }

    public viewMembership(membershipId): void{
        this.nav.push(ViewMembershipComponent, {'mewmbershipId': membershipId})
    }

    async loadMemberships(): Promise<any> {
        let loader = this.loadingCtrl.create();
        await loader.present();
        try{
            this.memberships = await this.http.get(this.config.getApiUrl() + '/memberships/')
                .map(res => res.json())
                .toPromise();
            this.memberships.forEach((membership) => {
                if (membership.current == true) {
                    this.currentMembership = membership.title;
                }

                // find for recurring plans
                if (membership.plans) {
                    membership.plans.forEach((plan: any) => {
                        if (parseInt(plan.dto.recurring)) {
                            this.isRecurringPlansAvailable = true;
                        }
                    });
                }
            });
        } catch(e) {}
        loader.dismiss();
    }

    /**
     * Show privacy policy modal
     */
    showPrivacyPolicyModal(): void {
        let modal = this.modalCtrl.create(CustomPageComponent, {
            title: this.translate.instant('privacy_policy_page_header'),
            pageName: 'privacy_policy_page_content'
        });

        modal.present();
    }

    /**
     * Show terms of use modal
     */
    showTermsOfUseModal(): void {
        let modal = this.modalCtrl.create(CustomPageComponent, {
            title: this.translate.instant('tos_page_header'),
            pageName: 'tos_page_content'
        });

        modal.present();
    }
}
