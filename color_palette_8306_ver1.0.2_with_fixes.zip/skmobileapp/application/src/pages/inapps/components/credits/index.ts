import { NavController, LoadingController } from 'ionic-angular';

import { Component } from '@angular/core';
import { SecureHttpService } from '../../../../services/http/index';
import { ConfigService } from '../../../../services/config/index';
import { AuthService} from '../../../../services/auth/index';
import { InAppsService} from '../../../../services/inapps/index';
import { ApiUtilsService } from '../../../../services/api/utils';

import { DashboardPage } from '../../../../pages/dashboard/index';

@Component({
    selector: 'credits',
    templateUrl: 'index.html'
})

export class CreditsComponent {
    private creditPacks: any = [];
    private creditBalance: number = 0;

    /**
     * Constructor
     */
    constructor(
        private auth: AuthService,
        private apiUtils: ApiUtilsService,
        private config: ConfigService,
        private http: SecureHttpService,
        private iaps: InAppsService,
        private loadingCtrl: LoadingController,
        private nav: NavController
    ){
        this.loadCreditPacks()
    }

    /**
     * Buy pack
     */
    async buyPack(definedProductId: string, originalProductId: string): Promise<any>{
        let loader = this.loadingCtrl.create();

        try {
            await loader.present();
            let result = await this.iaps.buyProduct(definedProductId, originalProductId);

            loader.dismiss();

            if (result) {
                this.apiUtils.clearUserData(this.auth.getUserId(), true);
                this.nav.push(DashboardPage)
            }
        }
        catch (e) {
            loader.dismiss();
        }
    }

    async loadCreditPacks(): Promise<any> {
        let loader = this.loadingCtrl.create();
        await loader.present();
        try{
            let data = await this.http.get(this.config.getApiUrl() + '/credits/')
                .map(res => res.json())
                .toPromise();

            let registeredProducts = await this.iaps.getProducts(data['packs']);

            // sync packs
            data['packs'] = data['packs'].filter((el: any) => {
                // process products from google or apple store
                for (let key in registeredProducts) {
                    let processedProduct: RegExp = new RegExp(registeredProducts[key]['productId'], 'i');

                    if (processedProduct.test(this.iaps.addPrefix(el.productId))) {
                        el.definedProductId = registeredProducts[key]['productId'];

                        return true;
                    }
                }

                return false;
            });

            this.creditPacks = data['packs'];
            this.creditBalance = data['balance'];
        } catch(e) {}
        loader.dismiss();
    }
}
