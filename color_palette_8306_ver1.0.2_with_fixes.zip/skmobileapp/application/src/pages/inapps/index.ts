import { Component, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { Slides, Events, NavController } from 'ionic-angular';

// pages
import { DashboardPage } from '../dashboard/index';

// mixins
import { Mixin } from '../../mixins/index';
import { BaseComponentMixin } from '../../mixins/baseComponent/index';

@Component({
    selector: 'inapps',
    templateUrl: 'index.html',
    providers: [
    ]
})
@Mixin([BaseComponentMixin])

export class InappsPage implements OnInit, OnDestroy {
    isPluginActive: (pluginKey: string|string[]) => boolean;

    @ViewChild('inappsSlider') slider: Slides;

    private activeComponent: string;
    private configsUpdatedHandler: () => void;

    /**
     * Constructor
     */
    constructor(
        private events: Events,
        private nav: NavController)
    {
        // init active component
        this.activeComponent = this.isPluginActive('membership') ? 'memberships' : 'credits';

        // -- init callbacks --//

        // configs updated handler
        this.configsUpdatedHandler = (): void => {
            // redirect to dashboard
            if (!this.isPluginActive('membership') && !this.isPluginActive('usercredits')) {
                this.nav.setRoot(DashboardPage);

                return;
            }

            // check the membership plugin
            if (!this.isPluginActive('membership') && this.activeComponent == 'memberships') {
                this.activeComponent = 'credits';

                return;
            }

            // check the credits plugin
            if (!this.isPluginActive('usercredits') && this.activeComponent == 'credits') {
                this.activeComponent = 'memberships';

                return;
            }
        };
    }

    /**
     * Component init
     */
    ngOnInit(): void {
        this.events.subscribe('configs:updated', this.configsUpdatedHandler);
    }

    /**
     * Component destroy
     */
    ngOnDestroy(): void {
        this.events.unsubscribe('configs:updated', this.configsUpdatedHandler);
    }

    /**
     * Select component
     */
    select(index): void {
        this.slider.slideTo(index);
    }
}
