import { Component, Input, ChangeDetectionStrategy, ChangeDetectorRef, OnInit, OnDestroy } from '@angular/core';
import { NavController, Events } from 'ionic-angular';
import { DataStore } from 'js-data';

// pages
import { InappsPage } from '../../../../pages/inapps/index';
import { EditUserQuestionsPage } from '../../../../pages/user/edit/questions/index';
import { EditUserPhotosPage } from '../../../../pages/user/edit/photos/index';
import { ProfileViewPage } from '../../../../pages/profile/view/index';
import { AppSettingsPage } from '../../../appSettings/index';
import { BookmarksPage } from '../../../../pages/user/bookmarks/index';
import { GuestsPage } from '../../../../pages/user/guests/index';
import { CompatibleUsersPage } from '../../../../pages/user/compatibleUsers/index';

// services
import { AuthService } from '../../../../services/auth/index';

// mixins
import { Mixin } from '../../../../mixins/index';
import { BaseComponentMixin } from '../../../../mixins/baseComponent/index';

@Component({
    selector: 'profile',
    templateUrl: 'index.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
@Mixin([BaseComponentMixin])

export class ProfileComponent implements OnInit, OnDestroy {
    isPluginActive: (pluginKey: string|string[]) => boolean;

    @Input() public activeComponent: string;

    private appSettingsPage = AppSettingsPage;
    private profileEditPage = EditUserQuestionsPage;
    private profileEditPhotosPage = EditUserPhotosPage;
    private bookmarksPage = BookmarksPage;
    private inappsPage = InappsPage;
    private guestsPage = GuestsPage;
    private compatibleUsersPage = CompatibleUsersPage;

    private guestsUpdatedHandler: () => void;
    private configsUpdatedHandler: () => void;

    /**
     * Constructor
     */
    constructor(
        private events: Events,
        private ref: ChangeDetectorRef,
        private auth: AuthService,
        private nav: NavController,
        private api: DataStore)
    {
        // -- init callbacks --//

        // guests updated handler
        this.guestsUpdatedHandler = (): void => {
            this.ref.markForCheck();
        };

        // configs updated handler
        this.configsUpdatedHandler = (): void => {
            this.ref.markForCheck();
        };
    }

    /**
     * Component init
     */
    ngOnInit(): void {
        this.events.subscribe('guests:updated', this.guestsUpdatedHandler);
        this.events.subscribe('configs:updated', this.configsUpdatedHandler);

    }

    /**
     * Component destroy
     */
    ngOnDestroy(): void {
        this.events.unsubscribe('guests:updated', this.guestsUpdatedHandler);
        this.events.unsubscribe('configs:updated', this.configsUpdatedHandler);
    }

    /**
     * User data
     */
    get user(): any {
        return this.api.get('users', this.auth.getUserId());
    }

    /**
     * Get new guests count
     */
    getNewGuestsCount(): number {
        return this.api.filter('guests', {
            where: {
                viewed: false
            }
        }).length;
    }

    /**
     * Show profile
     */
    showProfile(): void {
        this.nav.push(ProfileViewPage, {
            userId: this.auth.getUserId()
        });
    }
}
