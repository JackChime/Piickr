import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Events } from 'ionic-angular';
import { DataStore } from 'js-data';

// mixins
import { Mixin } from '../../../../mixins/index';
import { BaseComponentMixin } from '../../../../mixins/baseComponent/index';

@Component({
    selector: 'dashboard-tabs',
    templateUrl: 'index.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
@Mixin([BaseComponentMixin])

export class DashboardTabsComponent implements OnInit, OnDestroy {
    isPluginActive: (pluginKey: string|string[]) => boolean;
    isTinderSearchMode: () => boolean;
    isBrowseSearchMode: () => boolean;
    isBothSearchMode: () => boolean;

    @Input() activeComponent: string;
    @Input() activeSubComponent: string;
    @Output() componentChanged = new EventEmitter();

    private profilePage: string = 'profile';
    private hotListPage: string = 'hot-list';
    private tinderPage: string = 'tinder';
    private browsePage: string = 'search';
    private searchPage: string = 'search';
    private conversationsPage: string = 'conversations';

    private conversationsUpdatedHandler: () => void;
    private matchedUsersUpdatedHandler: () => void;
    private configsUpdatedHandler: () => void;

    /**
     * Constructor
     */
    constructor(
        private ref: ChangeDetectorRef,
        private events: Events,
        private api: DataStore)
    {
        // -- init callbacks --//

        // conversations updated handler
        this.conversationsUpdatedHandler = (): void => {
            this.ref.markForCheck();
        };

        // matched users updated handler
        this.matchedUsersUpdatedHandler = (): void => {
            this.ref.markForCheck();
        };

        // configs updated handler
        this.configsUpdatedHandler = (): void => {
            this.ref.markForCheck();
        };
    }

    /**
     * Component init
     */
     ngOnInit(): void {
        this.events.subscribe('matchedUsers:updated', this.matchedUsersUpdatedHandler);
        this.events.subscribe('conversations:updated', this.conversationsUpdatedHandler);
        this.events.subscribe('configs:updated', this.configsUpdatedHandler);
    }

    /**
     * Component destroy
     */
    ngOnDestroy(): void {
        this.events.unsubscribe('conversations:updated', this.conversationsUpdatedHandler);
        this.events.unsubscribe('matchedUsers:updated', this.matchedUsersUpdatedHandler);
        this.events.unsubscribe('configs:updated', this.configsUpdatedHandler);
    }

    /**
     * Is active sub component
     */
    isActiveSubComponent(name: string): boolean {
        if (this.activeSubComponent == name) {
            return true;
        }

        return false;
    }

    /**
     * Get general tabs class
     */
     generalTabsClass(): string {
        let isHotListActive: boolean = this.isPluginActive('hotlist');

        if ((this.isTinderSearchMode() || this.isBrowseSearchMode()) && !isHotListActive) {
            return 'sk-dashboard-single';
        }

        if (this.isBrowseSearchMode() && isHotListActive) {
            return 'sk-dashboard-hotlist-search';
        }

        if (this.isTinderSearchMode() && isHotListActive) {
            return 'sk-dashboard-hotlist-tinder';
        }

        if (this.isBothSearchMode() && !this.isPluginActive('hotlist')) {
            return 'sk-dashboard-tinder-search';
        }
    }

    /**
     * Change component
     */
    changeComponent(componentName: string, subComponentName?: string): void {
        this.componentChanged.emit({
            componentName: componentName,
            subComponentName: subComponentName
        });
    }

    /**
     * Get unread conversations count
     */
    get getUnreadConversationsCount(): number {
        return this.api.filter('conversations', {
            where: {
                isRead: false
            }
        }).length;
    }

    /**
     * Get new matched users count
     */
    get getNewMatchedUsersCount(): number {
        return this.api.filter('matchedUsers', {
            where: {
                isNew: true
            }
        }).length;
    }
}
