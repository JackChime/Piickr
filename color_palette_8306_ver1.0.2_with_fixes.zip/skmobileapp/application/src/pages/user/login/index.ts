import { Component, Input, OnInit, Inject, forwardRef, ChangeDetectorRef, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { NavController, AlertController, LoadingController, Events } from 'ionic-angular';
import { Facebook, FacebookLoginResponse } from '@ionic-native/facebook'
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';

// services
import { AuthService } from '../../../services/auth/index';
import { ConfigService } from '../../../services/config/index';
import { TranslateService } from 'ng2-translate';
import { SecureHttpService } from '../../../services/http/index';
import { ServerEventsService } from '../../../services/serverEvents/index';

// pages
import { AppUrlPage } from '../../appUrl/index';
import { DashboardPage } from '../../dashboard/index';
import { ForgotPasswordCheckEmailPage } from '../forgotPassword/checkEmail/index';
import { JoinInitialPage } from '../join/initial/index';

// questions
import { QuestionManager } from '../../../services/questions/manager';
import { QuestionControlService } from '../../../services/questions/control-service';

// mixins
import { Mixin } from '../../../mixins/index';
import { BaseComponentMixin } from '../../../mixins/baseComponent/index';

@Component({
    selector: 'login',
    templateUrl: 'index.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        QuestionControlService,
        QuestionManager
    ]
})
@Mixin([BaseComponentMixin])

export class LoginPage implements OnInit, OnDestroy {
    isPluginActive: (pluginKey: string|string[]) => boolean;

    @Input() questions = <any>[]; // list of questions

    private form: FormGroup;
    private appUrlPage = AppUrlPage;
    private joinPage = JoinInitialPage;
    private forgotPasswordPage = ForgotPasswordCheckEmailPage;
    private loginInProcessing: boolean = false;
    private http: SecureHttpService;

    private configsUpdatedHandler: () => void;

    /**
     * Constructor
     */
    constructor(
        private events: Events,
        private ref: ChangeDetectorRef,
        private serverEvents: ServerEventsService,
        private config: ConfigService,
        private fb: Facebook,
        @Inject(forwardRef(() => SecureHttpService)) http: SecureHttpService,
        private auth: AuthService,
        private loadingCtrl: LoadingController,
        private nav: NavController,
        private questionControl: QuestionControlService,
        private translate: TranslateService,
        private alert: AlertController,
        private questionManager: QuestionManager)
    {
        this.http = http;

        // -- init callbacks --//

        // configs updated handler
        this.configsUpdatedHandler = (): void => {
            this.ref.markForCheck();
        };
    }

    /**
     * Component init
     */
    ngOnInit(): void {
        this.events.subscribe('configs:updated', this.configsUpdatedHandler);

        this.serverEvents.restart();

        // create form items
        this.questions = [
            this.questionManager.getQuestion(QuestionManager.TYPE_TEXT, {
                key: 'login',
                label: this.translate.instant('login_input'),
                validators: [
                    {name: 'require'}
                ]
            }, {
                questionClass: 'sk-name',
                hideErrors: true,
                hideWarning: true
            }),
            this.questionManager.getQuestion(QuestionManager.TYPE_PASSWORD, {
                key: 'password',
                label: this.translate.instant('password_input'),
                validators: [
                    {name: 'require'}
                ]
            }, {
                questionClass: 'sk-password',
                hideErrors: true,
                hideWarning: true
            })
        ];

        // register all questions inside a form group
        this.form = this.questionControl.toFormGroup(this.questions);
    }

    /**
     * Component destroy
     */
    ngOnDestroy(): void {
        this.events.unsubscribe('configs:updated', this.configsUpdatedHandler);
    }

    /**
     * Is generic site url
     */
    get isGenericSiteUrl(): boolean {
        if (this.config.getGenericApiUrl()) {
            return true;
        }

        return false;
    }

    /**
     * Is facebook connect available
     */
    get isFacebookConnectAvailable(): boolean {
        return this.config.getConfig('facebookAppId') && this.isPluginActive('fbconnect');
    }

    /**
     * Login
     */
    async login(): Promise<any> {
        try {
            this.loginInProcessing = true;

            let data = await this.http.post(this.config.getApiUrl() + '/login/', JSON.stringify({
                    username: this.form.value.login,
                    password: this.form.value.password
                }))
                .map(res => res.json())
                .toPromise();

            this.loginInProcessing = false;

            if (data.success == true) {
                this.auth.setAuthenticated(data.token);
                this.nav.setRoot(DashboardPage);

                return;
            }

            this.loginFailed();
        }
        catch (e) {
            this.loginInProcessing = false;
            this.loginFailed();
        }
    }

    /**
     * Login failed
     */
    private loginFailed(): void {
        let alert = this.alert.create({
            title: this.translate.instant('error_occurred'),
            subTitle: this.translate.instant('login_failed'),
            buttons: [this.translate.instant('ok')]
        });

        alert.present();
    }

    /**
     * Facebook connect
     */
    async facebookLogin(): Promise<any> {
        let permissions = ['public_profile', 'email'];
        let loader = this.loadingCtrl.create();

        await loader.present();

        try {
            let facebookResponse: FacebookLoginResponse = await this.fb.login(permissions);
            let result = await this.http.post(
                    this.config.getApiUrl() + '/facebook-connect/',
                JSON.stringify(facebookResponse))
                .map(res => res.json())
                .toPromise();

            loader.dismiss();

            if (result.success == true) {
                this.auth.setAuthenticated(result.token);
                this.nav.setRoot(DashboardPage);
                return;
            }

            let alert = this.alert.create({
                message: result.error,
                buttons: [this.translate.instant('ok')]
            });

            alert.present();
        }
        catch(e) {
            loader.dismiss();
        }
    }
}
