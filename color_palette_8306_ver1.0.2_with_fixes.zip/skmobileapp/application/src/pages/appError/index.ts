import { Component, Inject, forwardRef } from '@angular/core';
import { NavController } from 'ionic-angular';
import { DataStore } from 'js-data';

// pages
import { DashboardPage } from '../dashboard/index';
import { LoginPage } from '../user/login/index';
import { AppMaintenancePage } from '../../pages/appMaintenance/index';

// services
import { AuthService } from '../../services/auth/index';
import { ApplicationService } from '../../services/application/index';

@Component({
    selector: 'app-error',
    templateUrl: 'index.html',
    providers: [
    ]
})

export class AppErrorPage {
    private application: ApplicationService;

    /**
     * Constructor
     */
    constructor(
        @Inject(forwardRef(() => ApplicationService)) application: ApplicationService,
        private api: DataStore,
        private auth: AuthService,
        private nav: NavController)
    {
        this.application = application;
    }

    /**
     * Is application ready
     */
    get isApplicationReady(): boolean {
        return this.application.isApplicationReady();
    }

    /**
     * Redirect
     */
    redirect(): void {
        this.nav.setRoot(!this.auth.isAuthenticated() ? LoginPage : DashboardPage);
    }

    /**
     * Do refresh
     */
    async doRefresh(refresher): Promise<any> {
        try {
            // refresh application dependencies
            await this.application.loadDependencies(false);
            refresher.complete();

            // redirect to the page
            if (this.api.get('configs', 'maintenanceMode').value) {
                this.nav.setRoot(AppMaintenancePage);

                return;
            }

            this.nav.setRoot(!this.auth.isAuthenticated() ? LoginPage : DashboardPage);
        }
        catch (e) {
            refresher.complete();
        }
    }

    /**
     * Logout user
     */
    logout(): void {
        this.auth.logout();
        this.nav.setRoot(LoginPage);
    }
}
