const prepare = require('./scripts/prepare');

prepare();