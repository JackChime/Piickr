const updateManifest = require('./scripts/updateManifest');

updateManifest();