<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */
namespace Skadate\Mobile\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Silex\Application as SilexApplication;
use MATCHMAKING_BOL_Service;
use BOL_AvatarService;
use OW;

class CompatibleUsers extends Base
{
    /**
     * Avatars relation
     */
    const AVATAR_RELATION = 'avatar';

    /**
     * Display name relation
     */
    const DISPLAY_NAME_RELATION = 'displayName';

    /**
     * User name relation
     */
    const USER_NAME_RELATION = 'userName';

    /**
     * Match actions relation
     */
    const MATCH_ACTIONS_RELATION = 'matchActions';

    /**
     * Users limit
     */
    const USERS_LIMIT = 500;

    /**
     * Is plugin active
     *
     * @var bool
     */
    protected $isPluginActive = false;

    /**
     * Relations
     *
     * @var array
     */
    protected $relations = [
        self::AVATAR_RELATION,
        self::DISPLAY_NAME_RELATION,
        self::USER_NAME_RELATION,
        self::MATCH_ACTIONS_RELATION
    ];

    /**
     * Connect methods
     *
     * @param SilexApplication $app
     * @return mixed
     */
    public function connect(SilexApplication $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];

        // get all matches
        $controllers->get('/', function (Request $request, SilexApplication $app) {
            if (!OW::getPluginManager()->isPluginActive('matchmaking')) {
                throw new BadRequestHttpException('Matchmaking plugin not activated');
            }

            $relations = $request->query->get('with', []);
            $loggedUserId = $app['users']->getLoggedUserId();

            $matchList = MATCHMAKING_BOL_Service::getInstance()->findMatchList($loggedUserId, 0, self::USERS_LIMIT);

            $ids = [];
            $processedMatchList = [];

            // process match list
            foreach ($matchList as $item) {
                $item['compatibility'] = MATCHMAKING_BOL_Service::getInstance()->getCompatibilityByValue($item['compatibility']);
                $processedMatchList[$item['id']] = $item;
                $ids[] = $item['id'];

                $emptyRelations = [];

                // add empty relations
                if ($relations) {
                    foreach($relations as $relation) {
                        if (in_array($relation, $this->relations)) {
                            $emptyRelations[$relation] = [];
                        }
                    }
                }

                $processedMatchList[$item['id']] = $item  + $emptyRelations;
            }

            // load relations
            if ($relations) {
                foreach($relations as $relation) {
                    if (in_array($relation, $this->relations)) {
                        switch ($relation) {
                            // load match actions
                            case self::MATCH_ACTIONS_RELATION :
                                if ($loggedUserId) {
                                    $mathList = $this->service->findUserMatchActionsByUserIdList($loggedUserId, $ids);

                                    foreach($mathList as $matchAction) {
                                        $processedMatchList[$matchAction->recipientId][$relation] = [
                                            'type' => $matchAction->type,
                                            'userId' => (int) $matchAction->recipientId,
                                            'isMutual' => boolval($matchAction->mutual)
                                        ];
                                    }
                                }
                                break;

                            // load avatars
                            case self::AVATAR_RELATION :
                                $avatarList = BOL_AvatarService::getInstance()->findByUserIdList($ids);

                                foreach($avatarList as $avatar) {
                                    $processedMatchList[$avatar->userId][$relation] = $this->service->getAvatarData($avatar, true);
                                }
                                break;

                            // load display names
                            case self::DISPLAY_NAME_RELATION :
                                // find display names
                                $displayNames = $this->userService->getDisplayNamesForList($ids);

                                foreach($displayNames as $userId => $displayName) {
                                    $processedMatchList[$userId]['displayName'] = $displayName;
                                }
                                break;

                            // load user names
                            case self::USER_NAME_RELATION :
                                // find user names
                                $userNames = $this->userService->getUserNamesForList($ids);

                                foreach($userNames as $userId => $userName) {
                                    $processedMatchList[$userId]['userName'] = $userName;
                                }
                                break;

                            default :
                        }
                    }
                }
            }

            $data = [];
            foreach($processedMatchList as $userData) {
                $data[] = $userData;
            }

            return $app->json($data);
        });

        return $controllers;
    }
}
