<?php
/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */
namespace Skadate\Mobile\Controller;

use Silex\Application as SilexApplication;
use Symfony\Component\HttpFoundation\Request;
use OW;
use MEMBERSHIP_BOL_MembershipService;
use BASE_CLASS_EventCollector;
use SKMOBILEAPP_BOL_InappsService;

class Memberships extends Base
{

    /**
     * @var SKMOBILEAPP_BOL_InappsService
     */
    private $inappsService;

    public function __construct()
    {
        parent::__construct();
        $this->inappsService = SKMOBILEAPP_BOL_InappsService::getInstance();
    }

    /**
     * Connect methods
     *
     * @param SilexApplication $app
     * @return mixed
     */
    public function connect(SilexApplication $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];

        $controllers->get('/', function (Request $request) use ($app) {
            $loggedUserId = $app['users']->getLoggedUserId();
            return $app->json($this->inappsService->getMemberships($loggedUserId));
        });

        $controllers->get('/me/', function (Request $request) use ($app) {
            $membershipService = $this->getMembershipService();
            $loggedUserId = $app['users']->getLoggedUserId();
            $membership = $membershipService->getUserMembership($loggedUserId);
            $type = $membershipService->findTypeById($membership->typeId);
            $data = array(
                'expirationStamp' => $membership->expirationStamp,
                'recurring' => $membership->recurring,
                'title' => $membershipService->getMembershipTitle($type->roleId),
            );

            return $app->json($data);
        });

        $controllers->get('/{id}/', function ($id, Request $request) use ($app) {
            $membershipService = $this->getMembershipService();
            $loggedUserId = $app['users']->getLoggedUserId();

            $type = $membershipService->findTypeById($id);

            $permissions = $this->authService->getPermissionList();

            $perms = array();
            foreach ( $permissions as $permission )
            {
                /* @var $permission BOL_AuthorizationPermission */
                $perms[$permission->roleId][$permission->actionId] = true;
            }


            $exclude = $membershipService->getUserTrialPlansUsage($loggedUserId);

            $mPlans = $membershipService->getTypePlanList($exclude);

            $actions = $membershipService->getSubscribePageGroupActionList();

            // collecting labels
            $event = new BASE_CLASS_EventCollector('admin.add_auth_labels');
            OW::getEventManager()->trigger($event);
            $data = $event->getData();

            $dataLabels = empty($data) ? array() : call_user_func_array('array_merge', $data);

            $dataLabels = array_map(function($item){
                $item['actions'] = isset($item['actions']) ? array_values($item['actions']) : array();
                return !empty($item['actions']) ? $item: null;
            }, $dataLabels);

            $dataLabels = array_filter($dataLabels, function($item) {return !is_null($item);});

            $data = array(
                'type' => $type,
                'plans' => isset($mPlans[$id]) ? $mPlans[$id] : null,
                'permissions' => $perms,
                'actions' => $actions,
                'labels' => array_values($dataLabels),
                'title' => $membershipService->getMembershipTitle($type->roleId),
            );

            return $app->json($data);
        });



        return $controllers;
    }

    private function getMembershipService()
    {
        if (!OW::getPluginManager()->isPluginActive('membership')) {
            throw new BadRequestHttpException('Membership plugin not activated');
        }
        return MEMBERSHIP_BOL_MembershipService::getInstance();
    }
}