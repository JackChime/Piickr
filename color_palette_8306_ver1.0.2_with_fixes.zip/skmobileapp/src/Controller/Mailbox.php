<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */
namespace Skadate\Mobile\Controller;

use Silex\Application as SilexApplication;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use OW;
use MAILBOX_BOL_ConversationService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Exception;
use SKMOBILEAPP_BOL_MailboxService;
use BOL_AuthorizationService;

class Mailbox extends Base
{
    /**
     * Is plugin active
     *
     * @var bool
     */
    protected $isPluginActive = false;

    /**
     * Mailbox service
     *
     * @var SKMOBILEAPP_BOL_MailboxService
     */
    protected $mailboxService;

    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct();

        $this->isPluginActive = OW::getPluginManager()->isPluginActive('mailbox');
        $this->mailboxService = SKMOBILEAPP_BOL_MailboxService::getInstance();
    }

    /**
     * Connect methods
     *
     * @param SilexApplication $app
     * @return mixed
     */
    public function connect(SilexApplication $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];


        // get history messages
        $controllers->get('/messages/history/', function (Request $request, SilexApplication $app) {
            if ($this->isPluginActive) {
                $beforeMessageId = $request->query->get('beforeMessageId', -1);
                $conversationId = $request->query->get('conversationId', -1);
                $limit = $request->query->get('limit', 0);

                return $app->json($this->
                    mailboxService->getHistoryMessages($app['users']->getLoggedUserId(), $conversationId, $beforeMessageId, $limit));
            }

            throw new BadRequestHttpException('Mailbox plugin not activated');
        });


        // update messages
        $controllers->put('/messages/', function (Request $request, SilexApplication $app) {
            if ($this->isPluginActive) {
                $messages = json_decode($request->getContent(), true);
                $loggedUserId = $app['users']->getLoggedUserId();
                $service = MAILBOX_BOL_ConversationService::getInstance();

                // mark messages as read
                $processedMessages = [];
                foreach($messages as $message) {
                    $messageId = !empty($message['id']) ? $message['id'] : null;

                    if ($messageId) {
                        $messageDto = $service->getMessage($messageId);

                        if ($messageDto && ($messageDto->senderId == $loggedUserId || $messageDto->recipientId == $loggedUserId)) {
                            $messageDto->recipientRead = true;
                            $service->markMessageRead($messageId);

                            $processedMessages[] = $this->mailboxService->getMessageData($loggedUserId, $messageDto->conversationId, $messageDto);
                        }
                    }
                }

                return $app->json($processedMessages);
            }

            throw new BadRequestHttpException('Mailbox plugin not activated');
        });


        // get message
        $controllers->get('/messages/{id}/', function (SilexApplication $app, $id) {
            if ($this->isPluginActive) {
                $service = MAILBOX_BOL_ConversationService::getInstance();
                $message = $service->getMessage($id);
                $loggedUserId = $app['users']->getLoggedUserId();

                if (empty($message) || ($message->senderId != $loggedUserId && $message->recipientId != $loggedUserId)) {
                    throw new BadRequestHttpException('Message not found');
                }

                // track action
                if (!$message->wasAuthorized) {
                    $trackResult = BOL_AuthorizationService::getInstance()->
                            trackActionForUser($loggedUserId, 'mailbox', 'read_chat_message', ['checkInterval' => false]);


                    if (!$trackResult['status']) {
                        throw new BadRequestHttpException('Message cannot be tracked');
                    }
                }

                $message = $service->markMessageAuthorizedToRead($id);

                return $app->json($this->mailboxService->getMessageData($loggedUserId, $message->conversationId, $message));
            }

            throw new BadRequestHttpException('Mailbox plugin not activated');
        });


        // photo messages
        $controllers->post('/photo-messages/', function (Request $request, SilexApplication $app) {
            try {
                if ($this->isPluginActive) {
                    $opponentId = $request->query->get('opponentId', -1);
                    $conversationId = $request->query->get('conversationId', null);

                    // check uploaded file
                    if (empty($_FILES['file']['tmp_name'])) {
                        throw new BadRequestHttpException('File was not uploaded');
                    }

                    if ($opponentId) {
                        return $app->json($this->mailboxService->createPhotoMessage($app['users']->
                                getLoggedUserId(), $opponentId, $_FILES['file'], $conversationId));
                    }

                    throw new BadRequestHttpException('opponentId is missing');
                }

                throw new BadRequestHttpException('Mailbox plugin not activated');
            }
            catch(Exception $e) {
                return new Response(json_encode(['shortDescription' => $e->getMessage()]), 404, [
                    'Content-Type' => 'application/json'
                ]);
            }
        });


        // create message
        $controllers->post('/messages/', function (Request $request, SilexApplication $app) {
            try {
                if ($this->isPluginActive) {
                    $vars = json_decode($request->getContent(), true);

                    $opponentId = !empty($vars['opponentId']) ? $vars['opponentId'] : -1;
                    $text = !empty($vars['text']) ? $this->service->removeEmoji($vars['text']) : '';
                    $conversationId = !empty($vars['conversationId']) ? $vars['conversationId'] : null;

                    if ($opponentId && $text) {
                        return $app->json($this->mailboxService->
                                createMessage($app['users']->getLoggedUserId(), $opponentId, $text, $conversationId));
                    }

                    throw new BadRequestHttpException('opponentId or  text param is missing');
                }

                throw new BadRequestHttpException('Mailbox plugin not activated');
            }
            catch(Exception $e) {
                return new Response(json_encode(['shortDescription' => $e->getMessage()]), 404, [
                    'Content-Type' => 'application/json'
                ]);
            }
        });


        // get all messages
        $controllers->get('/messages/', function (Request $request, SilexApplication $app) {
            if ($this->isPluginActive) {
                $conversationId = $request->query->get('conversationId', -1);
                $limit = $request->query->get('limit', 0);

                return $app->json($this->mailboxService->getMessages($app['users']->getLoggedUserId(), $conversationId, $limit));
            }

            throw new BadRequestHttpException('Mailbox plugin not activated');
        });


        // update conversation
        $controllers->put('/conversations/{id}/', function (Request $request, SilexApplication $app, $id) {
            if ($this->isPluginActive) {
                $vars = json_decode($request->getContent(), true);

                if (isset($vars['isRead'])) {
                    $service = MAILBOX_BOL_ConversationService::getInstance();
                    $loggedUserId = $app['users']->getLoggedUserId();

                    $vars['isRead'] === true ? $service->markRead([$id], $loggedUserId) : $service->markUnread([$id], $loggedUserId);

                    return $app->json($this->mailboxService->getConversations($loggedUserId, $id)[0]);
                }

                throw new BadRequestHttpException('isRead param is missing');
            }

            throw new BadRequestHttpException('Mailbox plugin not activated');
        });


        // delete conversation
        $controllers->delete('/conversations/{id}/', function (SilexApplication $app, $id) {
            if ($this->isPluginActive) {
                $count = MAILBOX_BOL_ConversationService::getInstance()->deleteConversation([$id], $app['users']->getLoggedUserId());

                if ($count) {
                    return $app->json(); // ok
                }

                throw new BadRequestHttpException('Conversation cannot be deleted');
            }

            throw new BadRequestHttpException('Mailbox plugin not activated');
        });


        // get all conversations
        $controllers->get('/conversations/', function (SilexApplication $app) {
            if ($this->isPluginActive) {
                return $app->json($this->mailboxService->getConversations($app['users']->getLoggedUserId()));
            }

            throw new BadRequestHttpException('Mailbox plugin not activated');
        });

        return $controllers;
    }
}
