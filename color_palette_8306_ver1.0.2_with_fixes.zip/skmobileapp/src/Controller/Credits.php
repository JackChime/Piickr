<?php
/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */
namespace Skadate\Mobile\Controller;

use Silex\Application as SilexApplication;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use OW;
use USERCREDITS_BOL_CreditsService;
use BOL_UserService;
use BOL_QuestionService;

use BASE_CLASS_EventCollector;

class Credits extends Base
{

    /**
     * Connect methods
     *
     * @param SilexApplication $app
     * @return mixed
     */
    public function connect(SilexApplication $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];

        $controllers->get('/', function (Request $request) use ($app) {
            
            if(OW::getPluginManager()->isPluginActive('usercredits'))
            {
                $creditsService = USERCREDITS_BOL_CreditsService::getInstance();

                $loggedUserId = $app['users']->getLoggedUserId();

                $balance = $creditsService->getCreditsBalance($loggedUserId);

                // get user account type
                $user = $this->userService->findUserById($loggedUserId);

                $accTypeName = $user->getAccountType();
                $accType = BOL_QuestionService::getInstance()->findAccountTypeByName($accTypeName);

                $packs = $creditsService->getPackList($accType->id);

                return $app->json(array('packs' => $packs, 'balance' => $balance));
            }
            throw new BadRequestHttpException('Usercredits plugin not activated');

        });

        return $controllers;
    }
}
