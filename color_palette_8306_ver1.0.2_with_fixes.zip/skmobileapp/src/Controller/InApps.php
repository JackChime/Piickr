<?php
/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */
namespace Skadate\Mobile\Controller;

use Silex\Application as SilexApplication;
use Symfony\Component\HttpFoundation\Request;

use SKMOBILEAPP_BOL_InappsService;

class InApps extends Base
{

    private $inappsService;

    public function __construct()
    {
        parent::__construct();

        $this->inappsService = SKMOBILEAPP_BOL_InappsService::getInstance();
    }

    /**
     * Connect methods
     *
     * @param SilexApplication $app
     * @return mixed
     */
    public function connect(SilexApplication $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];

        $controllers->post('/', function (Request $request) use ($app) {
            $data = json_decode($request->getContent(), true);

            if ($data['platform'] == 'android')
            {
                $result = $this->inappsService->validateAndroidPurchase($data);
            }
            elseif ($data['platform'] == 'ios')
            {
                $result = $this->inappsService->validateIOSPurchase($data);
            }
            else
            {
                return $app->json(array('id' => -1));
            }

            if ($result && $result['status']){
                $loggedUserId = $app['users']->getLoggedUserId();
                $this->inappsService->createAndDeliver($result, $data, $loggedUserId);
                $userMembership = $this->inappsService->getUserMembership($loggedUserId);
                return $app->json(array('id' => $userMembership->id));
            }

            return $app->json(array('id' => -1));
        });

        return $controllers;
    }

}
