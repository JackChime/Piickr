<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */
namespace Skadate\Mobile\Controller;

use Silex\Application as SilexApplication;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use BOL_AuthorizationService;
use SKADATE_BOL_AccountTypeToGenderService;
use BOL_EmailVerifyService;
use BOL_AvatarService;
use OW_Event;
use OW_EventManager;
use OW;
use BOL_QuestionService;
use USEARCH_BOL_Service;
use UTIL_DateTime;
use MATCHMAKING_BOL_Service;
use GOOGLELOCATION_BOL_LocationService;
use SKMOBILEAPP_BOL_BookmarksService;
use SKMOBILEAPP_BOL_PhotoService;
use MEMBERSHIP_BOL_MembershipService;

class Users extends Base
{
    /**
     * Default users limit
     */
    const DEFAULT_USERS_LIMIT = 100;

    /**
     * Bookmarks relation
     */
    const BOOKMARKS_RELATION = 'bookmarks';

    /**
     * Blocks relation
     */
    const BLOCKS_RELATION = 'blocks';

    /**
     * View questions relation
     */
    const VIEW_QUESTIONS_RELATION = 'viewQuestions';

    /**
     * Match actions relation
     */
    const MATCH_ACTIONS_RELATION = 'matchActions';

    /**
     * Avatars relation
     */
    const AVATAR_RELATION = 'avatar';

    /**
     * Compatibility relation
     */
    const COMPATIBILITY_RELATION = 'compatibility';

    /**
     * Distance relation
     */
    const DISTANCE_RELATION = 'distance';

    /**
     * Photos relation
     */
    const PHOTOS_RELATION = 'photos';

    /**
     * Permissions relation
     */
    const PERMISSIONS_RELATION = 'permissions';

    /**
     * Membership relation
     */
    const MEMBERSHIP_RELATION = 'membership';

    /**
     * @var SKADATE_BOL_AccountTypeToGenderService
     */
    protected $skadateService;

    /**
     * @var BOL_EmailVerifyService
     */
    protected $emailVerifyService;

    /**
     * Question service
     *
     * @var BOL_QuestionService
     */
    protected $questionService;

    /**
     * Authorization service
     *
     * @var BOL_AuthorizationService
     */
    protected $authorizationService;

    /**
     * Relations
     *
     * @var array
     */
    protected $relations = [
        self::BOOKMARKS_RELATION,
        self::BLOCKS_RELATION,
        self::VIEW_QUESTIONS_RELATION,
        self::MATCH_ACTIONS_RELATION,
        self::AVATAR_RELATION,
        self::COMPATIBILITY_RELATION,
        self::DISTANCE_RELATION,
        self::PHOTOS_RELATION,
        self::PERMISSIONS_RELATION,
        self::MEMBERSHIP_RELATION
    ];

    /**
     * Relations for short user data
     *
     * @var array
     */
    protected $shortRelations = [
        self::BLOCKS_RELATION,
        self::MATCH_ACTIONS_RELATION,
        self::AVATAR_RELATION
    ];

    /**
     * Users constructor
     */
    public function __construct()
    {
        parent::__construct();

        $this->skadateService = SKADATE_BOL_AccountTypeToGenderService::getInstance();
        $this->emailVerifyService = BOL_EmailVerifyService::getInstance();
        $this->avatarService = BOL_AvatarService::getInstance();
        $this->questionService = BOL_QuestionService::getInstance();
        $this->authorizationService = BOL_AuthorizationService::getInstance();
    }

    /**
     * Connect methods
     *
     * @param SilexApplication $app
     * @return mixed
     */
    public function connect(SilexApplication $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];


        // get all users
        $controllers->get('/', function (Request $request, SilexApplication $app) {
            if (OW::getPluginManager()->isPluginActive('usearch')) {
                $loggedUserId = $app['users']->getLoggedUserId();

                // process params
                $searchId = $request->query->get('searchId', 0);
                $relations = $request->query->get('with', []);
                $limit = (int) $request->query->get('limit', self::DEFAULT_USERS_LIMIT);

                if ($limit < 1) {
                    throw new BadRequestHttpException('Limit must be a positive number');
                }

                $foundUsers = USEARCH_BOL_Service::getInstance()->
                        getSearchResultList($searchId, USEARCH_BOL_Service::LIST_ORDER_NEW, 0, $limit);

                return $app->json($this->getFormattedUsersData($foundUsers, true, $relations, $loggedUserId));
            }

            throw new BadRequestHttpException('User search plugin not activated');
        });


        // get user short info
        $controllers->get('/{id}/short/', function (Request $request, SilexApplication $app, $id) {
            return $app->json($this->getUser($id,
                    $app['users']->getLoggedUserId(), $request->query->get('with', []), true));
        });

        // get user
        $controllers->get('/{id}/', function (Request $request, SilexApplication $app, $id) {
            $loggedUserId = $app['users']->getLoggedUserId();

            if ($loggedUserId != $id) {
                if (!$this->service->isPermissionAllowed($loggedUserId, 'base', 'view_profile')) {
                    throw new AccessDeniedHttpException;
                }

                $this->authService->trackActionForUser($loggedUserId, 'base', 'view_profile');
            }

            OW::getEventManager()->call('guests.track_visit', [
                'userId' => $id,
                'guestId' => $loggedUserId
            ]);

            OW::getEventManager()->call('guests.mark_guests_viewed', [
                'userId' => $loggedUserId,
                'guestIds' => [$id]
            ]);

            return $app->json($this->getUser($id, $loggedUserId, $request->query->get('with', [])));
        });


        // update user
        $controllers->put('/{id}/', function (Request $request, SilexApplication $app, $id) {
            $loggedUserId = $app['users']->getLoggedUserId();
            $data = json_decode($request->getContent(), true);

            if ($loggedUserId != $id) {
                throw new BadRequestHttpException('You can update only your self');
            }

            // update mode
            $mode = $request->query->get('mode');

            // trigger events before saving
            switch ($mode) {
                case 'completeAccountType' :
                    $event = new OW_Event( OW_EventManager::ON_BEFORE_USER_COMPLETE_ACCOUNT_TYPE, [
                        'user' => $loggedUserId
                    ]);

                    OW::getEventManager()->trigger($event);

                    break;

                default :
            }

            $userDto = $this->userService->findUserById($loggedUserId);

            $userData = [
                self::USERNAME_QUESTION_NAME => !empty($data[self::USERNAME_QUESTION_NAME])
                    ? $data[self::USERNAME_QUESTION_NAME]
                    : $userDto->getUsername(),

                self::EMAIL_QUESTION_NAME => !empty($data[self::EMAIL_QUESTION_NAME])
                    ? $data[self::EMAIL_QUESTION_NAME]
                    : $userDto->getEmail(),

                self::USER_ACCOUNT_QUESTION_NAME => !empty($data[self::USER_ACCOUNT_QUESTION_NAME])
                    ? $this->skadateService->getAccountType($data[self::USER_ACCOUNT_QUESTION_NAME])
                    : $userDto->getAccountType(),
            ];

            $this->questionService->saveQuestionsData($userData, $loggedUserId);

            // trigger events after saving
            switch ($mode) {
                case 'completeAccountType' :
                    $event = new OW_Event(OW_EventManager::ON_AFTER_USER_COMPLETE_PROFILE, [
                        'userId' => $loggedUserId
                    ]);

                    OW::getEventManager()->trigger($event);

                    break;

                default :
            }

            $token = $app['security.jwt.encoder']->encode(
                $this->service->getUserDataForToken($userDto->getId())
            );

            return $app->json(array_merge(
                $this->getUser($loggedUserId), [
                    'token' => $token
                ]
            ));
        });


        // create user
        $controllers->post('/', function(Request $request) use ($app) {
            $data = json_decode($request->getContent(), true);

            $event = new OW_Event(OW_EventManager::ON_BEFORE_USER_REGISTER, $data);
            OW::getEventManager()->trigger($event);

            $accountType = $this->skadateService->getAccountType($data['sex']);

            $user = $this->userService->createUser(
                $data['userName'],
                $data['password'],
                $data['email'],
                $accountType);

            // assign early uploaded avatar
            if ($data['avatarKey']) {
                OW::getSession()->set(BOL_AvatarService::AVATAR_CHANGE_SESSION_KEY, $data['avatarKey']);
                $this->avatarService->createAvatar($user->id, false, false);
            }
            else {
                OW::getSession()->set(BOL_AvatarService::AVATAR_CHANGE_SESSION_KEY, null);
            }

            $event = new OW_Event(OW_EventManager::ON_USER_REGISTER, [
                'userId' => $user->id,
                'method' => 'native',
                'params' => $data
            ]);

            OW::getEventManager()->trigger($event);

            if (OW::getConfig()->getValue('base', 'confirm_email')) {
                $this->emailVerifyService->sendUserVerificationMail($user);
            }

            // generate auth token
            $token = $app['security.jwt.encoder']->encode(
                $this->service->getUserDataForToken($user->id)
            );

            return $app->json(array_merge($this->getUser($user->id), [
                'token' => $token
            ]));
        });


        // delete user
        $controllers->delete('/{id}/', function($id) use ($app) {
            $loggedUserId = $app['users']->getLoggedUserId();

            if ($loggedUserId != $id) {
                throw new AccessDeniedHttpException;
            }

            $this->userService->deleteUser($loggedUserId, true);

            return $app->json(); // ok
        });

        return $controllers;
    }

    /**
     * Get formatted users data
     *
     * @param array $userList
     * @param boolean $hideEmail
     * @param array $relations
     * @param integer $loggedUserId
     * @param boolean $shortData
     * @return array
     */
    protected function getFormattedUsersData(array $userList, $hideEmail = true, array $relations = [], $loggedUserId = null, $shortData = false) {
        $ids = [];
        $processedUsers = [];
        $emptyRelations = [];

        // add empty relations
        if ($relations) {
            foreach($relations as $relation) {
                if (in_array($relation, (!$shortData ? $this->relations : $this->shortRelations))) {
                    $emptyRelations[$relation] = [];
                }
            }
        }

        foreach ($userList as $userDto) {
            $ids[] = $userDto->id;

            if (!$shortData) {
                $processedUsers[$userDto->id] = [
                    'id' => (int)$userDto->id,
                    'userName' => $userDto->username,
                    'email' => !$hideEmail ? $userDto->email : '',
                    'type' => $userDto->accountType,
                    'displayName' => '',
                    'aboutMe' => '',
                    'age' => '',
                    'isOnline' => false,
                    'isAdmin' => (bool)OW::getUser()->isAdmin()
                ] + $emptyRelations;
            }
            else {
                $processedUsers[$userDto->id] = [
                    'id' => (int)$userDto->id,
                    'userName' => $userDto->username,
                    'email' => !$hideEmail ? $userDto->email : '',
                    'displayName' => '',
                    'isOnline' => false
                ] + $emptyRelations;
            }
        }

        // find online statuses
        $onlineStatuses = $this->userService->findOnlineStatusForUserList($ids);

        foreach($onlineStatuses as $userId => $isOnline) {
            $processedUsers[$userId]['isOnline'] = (bool) $isOnline;
        }

        // find display names
        $displayNames = $this->userService->getDisplayNamesForList($ids);

        foreach($displayNames as $userId => $displayName) {
            $processedUsers[$userId]['displayName'] = $displayName;
        }

        // find some questions
        if (!$shortData) {
            $questionList = $this->questionService->getQuestionData($ids, ['birthdate', 'aboutme']);

            foreach ($questionList as $userId => $questions) {
                if (isset($questions['birthdate'])) {
                    $date = UTIL_DateTime::parseDate($questions['birthdate'], UTIL_DateTime::MYSQL_DATETIME_DATE_FORMAT);
                    $processedUsers[$userId]['age'] = UTIL_DateTime::getAge($date['year'], $date['month'], $date['day']);
                }

                $processedUsers[$userId]['aboutMe'] = isset($questions['aboutme']) ? $questions['aboutme'] : '';
            }
        }

        // load relations
        if ($relations) {
            foreach($relations as $relation) {
                if (in_array($relation, (!$shortData ? $this->relations : $this->shortRelations))) {
                    switch ($relation) {
                        // load match actions
                        case self::MATCH_ACTIONS_RELATION :
                            if ($loggedUserId) {
                                $mathList = $this->service->findUserMatchActionsByUserIdList($loggedUserId, $ids);

                                foreach($mathList as $matchAction) {
                                    $processedUsers[$matchAction->recipientId][$relation] = [
                                        'id' => (int) $matchAction->id,
                                        'userId' => (int) $matchAction->recipientId,
                                        'createStamp' => (int) $matchAction->createStamp,
                                        'isRead' => boolval($matchAction->read),
                                        'isNew' => boolval($matchAction->new),
                                        'isMutual' => boolval($matchAction->mutual),
                                        'type' => $matchAction->type
                                    ];
                                }
                            }
                            break;

                        // load permissions
                        case self::PERMISSIONS_RELATION :
                            $permissionList = $this->service->getPermissions($ids);

                            foreach($permissionList as $userId => $permissions) {
                                $processedUsers[$userId][$relation] = $permissions;
                            }
                            break;

                        // load compatibility
                        case self::COMPATIBILITY_RELATION :
                            if (!OW::getPluginManager()->isPluginActive('matchmaking')) {
                                throw new BadRequestHttpException('Matchmaking plugin not activated');
                            }

                            if ($loggedUserId) {
                                $result = MATCHMAKING_BOL_Service::getInstance()->
                                        findCompatibilityByUserIdList($loggedUserId, $ids, 0, count($ids));

                                foreach ($result as $item) {
                                    $processedUsers[$item['userId']][$relation] = [
                                        'userId' => (int)$item['userId'],
                                        'match' => (int)$item['compatibility']
                                    ];
                                }
                            }
                            break;

                        // load blocks
                        case self::BLOCKS_RELATION :
                            if ($loggedUserId) {
                                $result = $this->userService->findBlockedListByUserIdList($loggedUserId, $ids);

                                foreach ($result as $userId => $isBlocked) {
                                    $processedUsers[$userId][$relation] = [
                                        'userId' => $userId,
                                        'isBlocked' => $isBlocked
                                    ];
                                }
                            }
                            break;

                        // load bookmarks
                        case self::BOOKMARKS_RELATION :
                            if ($loggedUserId) {
                                if (!OW::getPluginManager()->isPluginActive('bookmarks')) {
                                    throw new BadRequestHttpException('Bookmarks plugin not activated');
                                }

                                $bookmarks = SKMOBILEAPP_BOL_BookmarksService::getInstance()->getMarkedListByUserId($loggedUserId, $ids);

                                foreach($bookmarks as $bookmark) {
                                    $processedUsers[$bookmark['markUserId']][$relation][] = $bookmark;
                                }
                            }
                            break;

                        // load distance
                        case self::DISTANCE_RELATION :
                            if ($loggedUserId) {
                                $loggedUserLocation = $this->service->findUserLocation($loggedUserId);

                                if ($loggedUserLocation) {
                                    $distanceUnit = $this->service->getDistanseUnits();
                                    $usersLocation = $this->service->findUsersLocation($ids);

                                    foreach ($usersLocation as $userLocation) {
                                        $distance = $this->service->distance($loggedUserLocation->latitude,
                                                $loggedUserLocation->longitude, $userLocation->latitude, $userLocation->longitude, $distanceUnit);

                                        $processedUsers[$userLocation->userId][$relation] = [
                                            'userId' => (int) $userLocation->userId,
                                            'distance' => (int) $distance < 1 ? 1 : (int) $distance,
                                            'unit' => $distanceUnit
                                        ];
                                    }
                                }
                            }
                            break;

                        // load avatar
                        case self::AVATAR_RELATION :
                            $avatarList = $this->avatarService->findByUserIdList($ids);

                            foreach($avatarList as $avatar) {
                                $processedUsers[$avatar->userId][$relation] = $this->service->getAvatarData($avatar);
                            }
                            break;

                        // load view questions
                        case self::VIEW_QUESTIONS_RELATION :
                            $excludedQuestions = [
                                'realname',
                                'birthdate'
                            ];

                            // check permissions
                            if ($loggedUserId && count($ids) == 1 && $ids[0] == $loggedUserId) { // don't check permissions for own questions
                                $viewQuestionList = $this->service->getViewQuestions($ids, $excludedQuestions);

                                foreach($viewQuestionList as $userId => $questions) {
                                    $processedUsers[$userId][$relation] = $questions;
                                }
                            }
                            else {
                                if (!$this->service->isPermissionAllowed($loggedUserId, 'base', 'view_profile')) {
                                    throw new AccessDeniedHttpException;
                                }

                                $viewQuestionList = $this->service->getViewQuestions($ids, $excludedQuestions);

                                foreach($viewQuestionList as $userId => $questions) {
                                    $processedUsers[$userId][$relation] = $questions;
                                }
                            }
                            break;

                        // load photos
                        case self::PHOTOS_RELATION :
                            if (!OW::getPluginManager()->isPluginActive('photo')) {
                                throw new BadRequestHttpException('Photo plugin not activated');
                            }

                            // check permissions
                            if ($loggedUserId && count($ids) == 1 && $ids[0] == $loggedUserId) { // don't check permissions for own photos
                                $photoList = SKMOBILEAPP_BOL_PhotoService::getInstance()->getUsersPhotoList($ids);

                                foreach($photoList as $userId => $photos) {
                                    $processedUsers[$userId][$relation] = $photos;
                                }
                            }
                            else {
                                if (!$this->service->isPermissionAllowed($loggedUserId, 'photo', 'view')) {
                                    throw new AccessDeniedHttpException;
                                }

                                $photoList = SKMOBILEAPP_BOL_PhotoService::getInstance()->getUsersPhotoList($ids);

                                foreach($photoList as $userId => $photos) {
                                    $processedUsers[$userId][$relation] = $photos;
                                }
                            }
                            break;

                        case self::MEMBERSHIP_RELATION :
                            if (!OW::getPluginManager()->isPluginActive('membership')) {
                                throw new BadRequestHttpException('Membership plugin not activated');
                            }
                            $membership = MEMBERSHIP_BOL_MembershipService::getInstance()->getUserMembership($userId);
                            if (is_null($membership))
                            {
                                /* @var $defaultRole BOL_AuthorizationRole */
                                $defaultRole = BOL_AuthorizationService::getInstance()->getDefaultRole();
                                $membership = new \stdClass();
                                $membership->type = null;
                                $membership->title = MEMBERSHIP_BOL_MembershipService::getInstance()->getMembershipTitle($defaultRole->id);

                            }
                            else
                            {
                                $membership->type = MEMBERSHIP_BOL_MembershipService::getInstance()->findTypeById($membership->typeId);
                                $membership->title = MEMBERSHIP_BOL_MembershipService::getInstance()->getMembershipTitle($membership->type->roleId);
                            }
                            $processedUsers[$userId][$relation] = $membership;
                            break;

                        default :
                    }
                }
            }
        }

        $data = [];
        foreach($processedUsers as $userData) {
            $data[] = $userData;
        }

        $event = new OW_Event('skmobileapp.formatted_users_data', [], $data);
        OW_EventManager::getInstance()->trigger($event);

        return $event->getData();
    }

    /**
     * Get user
     *
     * @param integer $userId
     * @param integer $loggedUserId
     * @param array $relations
     * @param boolean $shortData
     * @return array
     */
    protected function getUser($userId, $loggedUserId = null, array $relations = [], $shortData = false)
    {
        $userDto = $this->userService->findUserById($userId);

        if ($userDto === null) {
            throw new BadRequestHttpException('User not found');
        }

        $users = $this->getFormattedUsersData([$userDto], false, $relations, $loggedUserId, $shortData);

        return array_shift($users);
    }
}
