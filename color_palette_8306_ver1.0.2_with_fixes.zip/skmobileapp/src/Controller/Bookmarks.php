<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */
namespace Skadate\Mobile\Controller;

use Silex\Application as SilexApplication;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use BOOKMARKS_BOL_Service;
use SKMOBILEAPP_BOL_BookmarksService;
use BOL_AvatarService;
use OW;

class Bookmarks extends Base
{
    /**
     * Avatars relation
     */
    const AVATAR_RELATION = 'avatar';

    /**
     * Display name relation
     */
    const DISPLAY_NAME_RELATION = 'displayName';

    /**
     * User name relation
     */
    const USER_NAME_RELATION = 'userName';

    /**
     * Match actions relation
     */
    const MATCH_ACTIONS_RELATION = 'matchActions';

    /**
     * Is plugin active
     *
     * @var bool
     */
    protected $isPluginActive = false;

    /**
     * Relations
     *
     * @var array
     */
    protected $relations = [
        self::AVATAR_RELATION,
        self::DISPLAY_NAME_RELATION,
        self::USER_NAME_RELATION,
        self::MATCH_ACTIONS_RELATION
    ];

    /**
     * Users constructor
     */
    public function __construct()
    {
        parent::__construct();

        $this->avatarService = BOL_AvatarService::getInstance();
        $this->isPluginActive = OW::getPluginManager()->isPluginActive('bookmarks');
    }

    /**
     * Connect methods
     *
     * @param SilexApplication $app
     * @return mixed
     */
    public function connect(SilexApplication $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];


        // delete bookmark
        $controllers->delete('/{id}/', function (SilexApplication $app, $id) {
            if ($this->isPluginActive) {
                $loggedUserId = $app['users']->getLoggedUserId();
                BOOKMARKS_BOL_Service::getInstance()->unmark($loggedUserId, $id);

                return $app->json(); // ok
            }

            throw new BadRequestHttpException('Bookmarks plugin not activated');
        });


        // create bookmark
        $controllers->post('/', function (Request $request, SilexApplication $app) {
            if ($this->isPluginActive) {
                $vars = json_decode($request->getContent(), true);
                $loggedUserId = $app['users']->getLoggedUserId();

                if (!empty($vars['userId'])) {
                    $bookmarkId = BOOKMARKS_BOL_Service::getInstance()->mark($loggedUserId, $vars['userId']);

                    return $app->json([
                        'id' => (int) $bookmarkId,
                        'userId' => (int) $loggedUserId,
                        'markUserId' => (int) $vars['userId']
                    ]);
                }

                throw new BadRequestHttpException('userId is missing');
            }

            throw new BadRequestHttpException('Bookmarks plugin not activated');
        });


        // get all bookmark
        $controllers->get('/', function (Request $request, SilexApplication $app) {
            if ($this->isPluginActive) {
                $loggedUserId = $app['users']->getLoggedUserId();
                $relations = $request->query->get('with', []);

                $bookmarks = SKMOBILEAPP_BOL_BookmarksService::getInstance()->getMarkedListByUserId($loggedUserId);
                $processedBookmarks = [];
                $ids = [];

                // process bookmarks
                foreach($bookmarks as $bookmark) {
                    $ids[] = $bookmark['markUserId'];
                    $emptyRelations = [];

                    // add empty relations
                    if ($relations) {
                        foreach($relations as $relation) {
                            if (in_array($relation, $this->relations)) {
                                $emptyRelations[$relation] = [];
                            }
                        }
                    }

                    $processedBookmarks[$bookmark['markUserId']] = $bookmark + $emptyRelations;
                }

                // load relations
                if ($relations) {
                    foreach($relations as $relation) {
                        if (in_array($relation, $this->relations)) {
                            switch ($relation) {
                                // load match actions
                                case self::MATCH_ACTIONS_RELATION :
                                    if ($loggedUserId) {
                                        $mathList = $this->service->findUserMatchActionsByUserIdList($loggedUserId, $ids);

                                        foreach($mathList as $matchAction) {
                                            $processedBookmarks[$matchAction->recipientId][$relation] = [
                                                'type' => $matchAction->type,
                                                'userId' => (int) $matchAction->recipientId,
                                                'isMutual' => boolval($matchAction->mutual)
                                            ];
                                        }
                                    }
                                    break;

                                // load avatars
                                case self::AVATAR_RELATION :
                                    $avatarList = $this->avatarService->findByUserIdList($ids);

                                    foreach($avatarList as $avatar) {
                                        $processedBookmarks[$avatar->userId][$relation] = $this->service->getAvatarData($avatar);
                                    }
                                    break;

                                // load display names
                                case self::DISPLAY_NAME_RELATION :
                                    // find display names
                                    $displayNames = $this->userService->getDisplayNamesForList($ids);

                                    foreach($displayNames as $userId => $displayName) {
                                        $processedBookmarks[$userId]['displayName'] = $displayName;
                                    }
                                    break;

                                // load user names
                                case self::USER_NAME_RELATION :
                                    // find user names
                                    $userNames = $this->userService->getUserNamesForList($ids);

                                    foreach($userNames as $userId => $userName) {
                                        $processedBookmarks[$userId]['userName'] = $userName;
                                    }
                                    break;

                                default :
                            }
                        }
                    }
                }

                $data = [];
                foreach($processedBookmarks as $bookmarkData) {
                    $data[] = $bookmarkData;
                }

                return $app->json($data);
            }

            throw new BadRequestHttpException('Bookmarks plugin not activated');
        });


        return $controllers;
    }
}
