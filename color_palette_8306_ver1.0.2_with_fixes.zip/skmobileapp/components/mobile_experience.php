<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */
class SKMOBILEAPP_CMP_MobileExperience extends BASE_CLASS_Widget
{
    const IOS = 'skadateios';
    const ANDROID = 'skandroid';

    const IOS_APP_URL = 'ios_app_url';
    const ANDROID_APP_URL = 'android_app_url';

    public function __construct( BASE_CLASS_WidgetParameter $paramObj )
    {
        parent::__construct();

        $config = OW::getConfig();
        $pluginManager = OW::getPluginManager();

        $appUrls = array(
            self::IOS => $config->getValue('skmobileapp', self::IOS_APP_URL),
            self::ANDROID => $config->getValue('skmobileapp', self::ANDROID_APP_URL)
        );

        if ( !$appUrls[self::IOS] && !$appUrls[self::ANDROID] )
        {
            $this->setVisible(false);

            return;
        }
        elseif ( empty($paramObj->customParamList['banners']) )
        {
            $this->setVisible(false);

            return;
        }

        $banners = $paramObj->customParamList['banners'];
        $banners = array_merge(array($paramObj->customParamList['show_first'] => true), $banners);

        $promos = array();

        foreach ( array_keys($banners) as $banner )
        {
            if ( !$appUrls[$banner] )
            {
                continue;
            }

            $promos[$banner] = array(
                'app_url' => $appUrls[$banner]
            );
        }

        if ( count($promos) === 0 )
        {
            $this->setVisible(false);

            return;
        }

        $this->assign('promos', $promos);
        $this->setTemplate($pluginManager->getPlugin('skadate')->getCmpViewDir() . 'mobile_experience.html');
        OW::getDocument()->addStyleSheet($pluginManager->getPlugin('skadate')->getStaticCssUrl() . 'mobile_experience.css');
    }

    public static function getStandardSettingValueList()
    {
        return array(
            self::SETTING_TITLE => OW::getLanguage()->text('skadate', 'mobile_experience_widget_title'),
            self::SETTING_ICON => self::ICON_PICTURE,
            self::SETTING_SHOW_TITLE => false,
            self::SETTING_WRAP_IN_BOX => false
        );
    }

    public static function getSettingList()
    {
        $config = OW::getConfig();
        $language = OW::getLanguage();

        $appUrls = array(
            self::IOS => $config->getValue('skmobileapp', self::IOS_APP_URL),
            self::ANDROID => $config->getValue('skmobileapp', self::ANDROID_APP_URL)
        );

        $hasIosAppUrl = !empty($appUrls[self::IOS]);
        $hasAndroidAppUrl = !empty($appUrls[self::ANDROID]);

        return array(
            'banners' => array(
                'presentation' => self::PRESENTATION_CUSTOM,
                'label' => $language->text('skadate', 'banners_label'),
                'render' => function( $uniqName, $name, $value ) use ($hasIosAppUrl, $hasAndroidAppUrl) {
                    $document = OW::getDocument();
                    $language = OW::getLanguage();

                    $document->addScript(OW::getPluginManager()->getPlugin('skadate')->getStaticJsUrl() . 'mobile_experience.js');
                    $document->addOnloadScript(UTIL_JsGenerator::composeJsString(';window.SKADATE_ME_SETTINGS({$params});', array(
                        'params' => array(
                            'iosActive' => $hasIosAppUrl,
                            'androidActive' => $hasAndroidAppUrl
                        )
                    )));

                    $input = new CheckboxGroup('banners');
                    $input->setOptions(array(
                        self::IOS => $language->text('skadate', 'ios_label'),
                        self::ANDROID => $language->text('skadate', 'android_label')
                    ));
                    $input->setColumnCount(2);
                    $input->setValue(!empty($value) ? array_keys($value) : null);

                    return $input->renderInput();
                },
                'value' => array(
                    self::IOS => $hasIosAppUrl,
                    self::ANDROID => $hasAndroidAppUrl
                )
            ),
            'show_first' => array(
                'presentation' => self::PRESENTATION_CUSTOM,
                'label' => $language->text('skadate', 'show_first_label'),
                'render' => function( $uniqName, $name, $value ) use ($hasIosAppUrl, $hasAndroidAppUrl) {
                    $language = OW::getLanguage();

                    $input = new RadioField('show_first[]');
                    $input->setOptions(array(
                        self::IOS => $language->text('skadate', 'ios_label'),
                        self::ANDROID => $language->text('skadate', 'android_label')
                    ));
                    $input->setValue($value);
                    $input->setColumnCount(2);

                    return $input->renderInput();
                },
                'value' => $hasIosAppUrl ? self::IOS : self::ANDROID
            )
        );
    }

    public static function processSettingList( $settingList, $place, $isAdmin )
    {
        $config = OW::getConfig();

        $appUrls = array(
            self::IOS => $config->getValue('skmobileapp', self::IOS_APP_URL),
            self::ANDROID => $config->getValue('skmobileapp', self::ANDROID_APP_URL)
        );

        $settingList = parent::processSettingList($settingList, $place, $isAdmin);

        $settingList['show_first'] = array_shift($settingList['show_first']);
        $settingList['banners'] = array_flip($settingList['banners']);

        if ( empty($appUrls[self::IOS]) && isset($settingList['banners'][self::IOS]) )
        {
            unset($settingList['banners'][self::IOS]);
        }

        if ( empty($appUrls[self::ANDROID]) && isset($settingList['banners'][self::ANDROID]) )
        {
            unset($settingList['banners'][self::ANDROID]);
        }

        return $settingList;
    }
}