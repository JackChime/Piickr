<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */

$pluginKey = 'skmobileapp';
$config = OW::getConfig();

OW::getPluginManager()->addPluginSettingsRouteName($pluginKey, $pluginKey . '_admin_ads');

$defaultConfigs = array(
    'import_location_last_user_id' => 0,
    'ads_api_key' => '',
    'ads_enabled' => false,
    'pn_sender_id' => '',
    'pn_server_key' => '',
    'pn_apns_pass_phrase' => '',
    'pn_apns_mode' => '',
    'pn_enabled' => false,
    'inapps_apm_key' => '',
    'inapps_itunes_shared_secret' => '',
    'inapps_ios_test_mode' => false,
    'ios_app_url' => 'https://itunes.apple.com/in/app/date-finder-app/id1263891062?mt=8',
    'android_app_url' => 'https://play.google.com/store/apps/details?id=com.skmobile&hl=en',
    'search_mode' => 'both'
);

foreach ($defaultConfigs as $key => $value)
{
    if ( !$config->configExists($pluginKey, $key) )
    {
        $config->addConfig($pluginKey, $key, $value);
    }
}

$sql = "CREATE TABLE IF NOT EXISTS `".OW_DB_PREFIX . $pluginKey ."_devices` (
    `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `userId` int(11) UNSIGNED NOT NULL,
    `uuid` varchar(255) NOT NULL,
    `token` text,
    `platform` varchar(255) NOT NULL,
    `activityTime` int(11) UNSIGNED DEFAULT NULL,
    `properties` text NOT NULL,
    `addTime` int(11) UNSIGNED NOT NULL,
    PRIMARY KEY (`id`),
    KEY `userId` (`userId`),
    KEY `uuid` (`uuid`(30))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";

OW::getDbo()->query($sql);

// create db tables
$sql = "CREATE TABLE IF NOT EXISTS `" . OW_DB_PREFIX . $pluginKey . "_user_match_action` (
    `id` int(11) NOT NULL auto_increment,
    `userId` int(11) NOT NULL,
    `recipientId` int(11) NOT NULL,
    `type` varchar(20) NOT NULL,
    `createStamp` int(11) NOT NULL,
    `expirationStamp` int(11) NOT NULL,
    `mutual` tinyint(1) NOT NULL DEFAULT 0,
    `read` tinyint(1) NOT NULL DEFAULT 0,
    `new` tinyint(1) NOT NULL DEFAULT 0,
    PRIMARY KEY  (`id`),
    UNIQUE KEY `userMatch` (`userId`, `recipientId`),
    KEY `expiration` (`userId`, `recipientId`, `type`, `expirationStamp`),
    KEY `mutual` (`userId`, `type`, `mutual`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";

OW::getDbo()->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS `".OW_DB_PREFIX . $pluginKey ."_user_location` (
    `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `userId` int(11) UNSIGNED NOT NULL,
    `latitude` DECIMAL( 15, 4 ) NOT NULL,
    `longitude` DECIMAL( 15, 4 ) NOT NULL,
    `northEastLatitude` DECIMAL( 15, 4 ) NOT NULL,
    `northEastLongitude` DECIMAL( 15, 4 ) NOT NULL,
    `southWestLatitude` DECIMAL( 15, 4 ) NOT NULL,
    `southWestLongitude` DECIMAL( 15, 4 ) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `userId` (`userId`),
    KEY `userLocation` (`userId`, `southWestLatitude`, `northEastLatitude`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";

OW::getDbo()->query($sql);

$billingService = BOL_BillingService::getInstance();

$gateway = new BOL_BillingGateway();
$gateway->gatewayKey = $pluginKey;
$gateway->adapterClassName = 'SKMOBILE_CLASS_InAppPurchaseAdapter';
$gateway->active = 0;
$gateway->mobile = 1;
$gateway->recurring = 1;
$gateway->dynamic = 0;
$gateway->hidden = 1;
$gateway->currencies = 'AUD,CAD,EUR,GBP,JPY,USD';

$billingService->addGateway($gateway);

// import languages
$plugin = OW::getPluginManager()->getPlugin($pluginKey);
OW::getLanguage()->importLangsFromDir($plugin->getRootDir() . 'langs');
