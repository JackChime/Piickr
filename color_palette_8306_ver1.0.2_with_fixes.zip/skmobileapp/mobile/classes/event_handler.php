<?php

/**
 * Copyright (c) 2016, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */
class SKMOBILEAPP_MCLASS_EventHandler extends SKMOBILEAPP_CLASS_AbstractEventHandler
{
    use OW_Singleton;

    /**
     * Init
     */
    public function init()
    {
        parent::genericInit();

        $requestHandler = OW::getRequestHandler();

        $requestHandler->addCatchAllRequestsExclude('base.password_protected', 'SKMOBILEAPP_MCTRL_Api', 'index');
        $requestHandler->addCatchAllRequestsExclude('base.members_only', 'SKMOBILEAPP_MCTRL_Api', 'index');
        $requestHandler->addCatchAllRequestsExclude('base.maintenance_mode', 'SKMOBILEAPP_MCTRL_Api', 'index');
        $requestHandler->addCatchAllRequestsExclude('base.email_verify', 'SKMOBILEAPP_MCTRL_Api', 'index');
        $requestHandler->addCatchAllRequestsExclude('base.suspended_user', 'SKMOBILEAPP_MCTRL_Api', 'index');
        $requestHandler->addCatchAllRequestsExclude('base.wait_for_approval', 'SKMOBILEAPP_MCTRL_Api', 'index');
        $requestHandler->addCatchAllRequestsExclude('base.complete_profile', 'SKMOBILEAPP_MCTRL_Api', 'index');
        $requestHandler->addCatchAllRequestsExclude('base.complete_profile.account_type', 'SKMOBILEAPP_MCTRL_Api', 'index');
        $requestHandler->addCatchAllRequestsExclude('lpage.main', 'SKMOBILEAPP_MCTRL_Api', 'index');
    }
}
